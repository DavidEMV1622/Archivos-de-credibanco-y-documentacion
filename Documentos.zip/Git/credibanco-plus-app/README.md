# CanalApp


## Como comenzar
Proyecto de Credibanco - Canal App creado en Flutter 

Instalar el sdk de Flutter 
https://flutter.dev/docs/get-started/install
### Prerequisitos
```
    - Agregar a la variable de entorno Path C:/Users/#elsuaurio/flutter/bin
    - Ejecutar "flutter pub get" en la raiz del proyecto en una terminal
```
#### Correr el proyecto en un dispositvo Android
```
    Instalar Android Studio
        - Crear un emulador Android
```
#### Correr el proyecto en un dispositvo Ios
    Unicamente en un disposito Mac Os
```
    Instalar Xcode
        - Crear un emulador Ios
```

## Ejecutar "flutter run" en la raiz del proyecto en una terminal




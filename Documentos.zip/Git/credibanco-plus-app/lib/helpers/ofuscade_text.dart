String hideEmail(String email) {
  if (email == "") return "";
  int indiceArroba = email.indexOf('@');
  String parteLocal = email.substring(0, indiceArroba);
  String dominio = email.substring(indiceArroba + 1);
  int indice = parteLocal.length >= 4 ? 3 : 1;
  String parteLocalOfuscada = parteLocal.replaceRange(indice, null, '****');
  return '$parteLocalOfuscada@$dominio'.toLowerCase();
}

import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  static late SharedPreferences _prefs;

  static String _token = '';

  static Future init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static String get token {
    return _prefs.getString('token') ?? _token;
  }

  static set token(String token) {
    _token = token;
    _prefs.setString("token", token);
  }

  static void setidUser(String idUser) {
    _prefs.setString("idUser", idUser);
  }

  static String? getidUser() {
    return _prefs.getString('idUser');
  }

  static void setEmail(String email) {
    _prefs.setString("email", email);
  }

  static String? getEmail() {
    return _prefs.getString('email');
  }

  static void setRole(String role) {
    _prefs.setString("role", role);
  }

  static String? getRole() {
    return _prefs.getString('role');
  }
}

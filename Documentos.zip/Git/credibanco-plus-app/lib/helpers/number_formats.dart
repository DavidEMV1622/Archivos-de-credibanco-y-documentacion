import 'package:intl/intl.dart';

class NumberFormats {
  static String currencyFormat(String number) {
    final cleanNumber = number.replaceAll("\$", "").replaceAll(".", "").trim();
    if (cleanNumber == "") return number;
    return NumberFormat.decimalPattern("es_Es")
        .format(double.tryParse(cleanNumber));
  }
}

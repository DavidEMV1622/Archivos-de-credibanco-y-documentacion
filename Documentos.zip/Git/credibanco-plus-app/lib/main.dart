import 'package:credibanco_plus_app/config/theme/app_theme.dart';
import 'package:credibanco_plus_app/helpers/helpers.dart';
import 'package:credibanco_plus_app/presentation/controllers/user_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'package:credibanco_plus_app/config/app_routes/routes.dart';
import 'package:get/get.dart';

Future main() async {
  await dotenv.load(fileName: '.env');
  await Preferences.init();
  Get.put(UserController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      routerConfig: appRouter,
      title: 'Credibanco Plus',
      theme: AppTheme().getTheme().copyWith(
            useMaterial3: true,
          ),
    );
  }
}

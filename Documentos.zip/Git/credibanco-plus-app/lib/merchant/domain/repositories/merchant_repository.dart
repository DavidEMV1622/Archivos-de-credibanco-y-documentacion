import '../entities/merchant_nit_info.dart';

abstract class MerchantRepository {
  Future<MerchantNitInfo?> validateNit({required String nit});
}

import '../entities/merchant_nit_info.dart';

abstract class MerchantDataSource {
  Future<MerchantNitInfo?> validateNit({required String nit});
}

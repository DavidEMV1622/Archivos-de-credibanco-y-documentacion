class MerchantNitInfo {
  final String name;
  final String nit;
  final String? document;
  final String? phone;
  final String? email;

  MerchantNitInfo(
      {required this.name,
      required this.nit,
      required this.document,
      required this.phone,
      required this.email});
}

import 'dart:convert';

ResVlidateNit resVlidateNItFromJson(String str) =>
    ResVlidateNit.fromJson(json.decode(str));

String resVlidateNItToJson(ResVlidateNit data) => json.encode(data.toJson());

class ResVlidateNit {
  final DateTime date;
  final String message;
  final Content content;

  ResVlidateNit({
    required this.date,
    required this.message,
    required this.content,
  });

  factory ResVlidateNit.fromJson(Map<String, dynamic> json) => ResVlidateNit(
        date: DateTime.parse(json["date"]),
        message: json["message"],
        content: Content.fromJson(json["content"]),
      );

  Map<String, dynamic> toJson() => {
        "date": date.toIso8601String(),
        "message": message,
        "content": content.toJson(),
      };
}

class Content {
  final String name;
  final String nit;
  final String? document;
  final String? phone;
  final String? email;

  Content({
    required this.name,
    required this.nit,
    this.document,
    this.phone,
    this.email,
  });

  factory Content.fromJson(Map<String, dynamic> json) => Content(
        name: json["name"],
        nit: json["nit"],
        document: json["document"],
        phone: json["phone"],
        email: json["email"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "nit": nit,
        "document": document,
        "phone": phone,
        "email": email,
      };
}

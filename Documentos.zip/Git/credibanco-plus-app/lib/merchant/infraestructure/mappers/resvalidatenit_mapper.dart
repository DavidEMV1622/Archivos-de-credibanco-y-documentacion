import '../../infraestructure/models/resnit_merchantapi.dart';
import '../../domain/entities/merchant_nit_info.dart';

class ResvalidatenitMapper {
  static MerchantNitInfo merchantApiToResNit(ResVlidateNit resNit) =>
      MerchantNitInfo(
          name: resNit.content.name,
          nit: resNit.content.nit,
          document: resNit.content.document,
          phone: resNit.content.phone,
          email: resNit.content.email);
}

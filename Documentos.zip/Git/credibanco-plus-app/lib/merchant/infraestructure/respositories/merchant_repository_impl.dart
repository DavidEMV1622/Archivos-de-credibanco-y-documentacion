import 'package:credibanco_plus_app/merchant/domain/entities/merchant_nit_info.dart';
import '../../domain/datasources/merchant_data_source.dart';
import '../../domain/repositories/merchant_repository.dart';

class MerchantRepositoryImpl extends MerchantRepository {
  final MerchantDataSource dataSource;

  MerchantRepositoryImpl(this.dataSource);

  @override
  Future<MerchantNitInfo?> validateNit({required String nit}) {
    return dataSource.validateNit(nit: nit);
  }
}

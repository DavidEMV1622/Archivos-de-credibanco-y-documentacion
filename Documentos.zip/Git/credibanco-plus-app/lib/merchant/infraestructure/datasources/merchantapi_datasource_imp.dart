import 'package:credibanco_plus_app/config/constants/environment.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'package:credibanco_plus_app/merchant/domain/datasources/merchant_data_source.dart';
import 'package:credibanco_plus_app/merchant/domain/entities/merchant_nit_info.dart';
import 'package:credibanco_plus_app/merchant/infraestructure/mappers/resvalidatenit_mapper.dart';
import 'package:credibanco_plus_app/merchant/infraestructure/models/resnit_merchantapi.dart';

class MerchantapiDatasourceImp extends MerchantDataSource {
  final storage = const FlutterSecureStorage();

  final dio = Dio(BaseOptions(
      baseUrl:
          'https://merchant-api-merchants.${Environment.baseUrl}/merchant/'));
  @override
  Future<MerchantNitInfo?> validateNit({required String nit}) async {
    final token = await storage.read(key: "tokenAnonymus");

    try {
      final response = await dio.get("contact/extract/$nit",
          options: Options(headers: {'Authorization': 'Bearer $token'}));

      if (response.statusCode != 200) return null;
      return ResvalidatenitMapper.merchantApiToResNit(
          ResVlidateNit.fromJson(response.data));
    } on DioException catch (e) {
      e;
      return null;
    }
  }
}

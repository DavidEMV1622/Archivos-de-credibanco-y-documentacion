import 'package:credibanco_plus_app/merchant/domain/entities/merchant_nit_info.dart';
import 'package:credibanco_plus_app/merchant/infraestructure/datasources/merchantapi_datasource_imp.dart';
import 'package:credibanco_plus_app/merchant/infraestructure/respositories/merchant_repository_impl.dart';

class MerchantController {
  static MerchantRepositoryImpl repository =
      MerchantRepositoryImpl(MerchantapiDatasourceImp());

  static Future<MerchantNitInfo?> validateNit(String nit) async {
    return await repository.validateNit(nit: nit);
  }
}

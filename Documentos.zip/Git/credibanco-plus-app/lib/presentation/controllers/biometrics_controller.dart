import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:local_auth/error_codes.dart' as auth_error;
import 'package:local_auth_android/local_auth_android.dart';
import 'package:local_auth_ios/local_auth_ios.dart';

class BiometricsController extends GetxController {
  @override
  void onInit() async {
    await canAuthenticate();
    super.onInit();
  }

  final canAuth = Rxn<bool>(false);
  final isError = Rxn<bool>(false);
  final msgError = Rxn<String>("");
  final LocalAuthentication auth = LocalAuthentication();

  final availableBiometrics = Rxn<List<BiometricType>>();

  Future<bool?> getisDisabled() async {
    final bool isAvailable = await auth.isDeviceSupported();
    if (!isAvailable) return null;
    final bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
    return !canAuthenticateWithBiometrics;
  }

  Future canAuthenticate() async {
    final bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
    final bool canAuthenticate =
        canAuthenticateWithBiometrics || await auth.isDeviceSupported();
    await getAvailableBiometrics();
    canAuth.value = (canAuthenticate &&
            (availableBiometrics.value!.contains(BiometricType.face)) ||
        availableBiometrics.value!.contains(BiometricType.fingerprint));
  }

  Future getAvailableBiometrics() async {
    availableBiometrics.value = await auth.getAvailableBiometrics();
  }

  Future<bool> autenticar() async {
    try {
      final bool didAuthenticate = await auth.authenticate(
          localizedReason: 'Por favor autenticate para ingresar',
          options: AuthenticationOptions(useErrorDialogs: false));
      isError.value = !didAuthenticate;
      return didAuthenticate;
    } on PlatformException catch (e) {
      if (e.code == auth_error.lockedOut) {
        msgError.value = "Maximo numero de intentos superados";
      }
      isError.value = true;
      return false;
    }
  }
}

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

class UserController extends GetxController {
  final storage = const FlutterSecureStorage();
  final isLogged = Rxn<bool>(false);
  final userEmail = Rxn<String>();

  @override
  void onInit() async {
    final user = await storage.read(key: "user");
    print(user);
    if (user != null && user != "") {
      userEmail.value = user;
    }
  }
}

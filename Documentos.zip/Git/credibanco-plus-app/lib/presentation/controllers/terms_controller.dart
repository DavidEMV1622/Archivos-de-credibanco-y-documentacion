import 'package:credibanco_plus_app/terms/domain/entities/terminos.dart';
import 'package:credibanco_plus_app/terms/infraestructure/datasources/portal_mf_datasource_imp.dart';
import 'package:credibanco_plus_app/terms/infraestructure/repositories/portal_mf_terms_repository_impl.dart';

class TermsController {
  static TermsRepositoryImple repository =
      TermsRepositoryImple(PortalMfDatasource());

  static Future<Termns> getTerms(String idTerms) async {
    return await repository.getTerms(idTerms);
  }

  static Future<bool> acceptTerms(String idTerms, String user) async {
    return await repository.acceptTerms(idTerms, user);
  }
}

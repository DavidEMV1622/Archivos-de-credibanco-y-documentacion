import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

import 'package:credibanco_plus_app/config/constants/environment.dart';
import 'package:credibanco_plus_app/presentation/controllers/user_controller.dart';
import 'package:credibanco_plus_app/token/infraestructure/datasources/portalmfapi_datasource_imp.dart';
import 'package:credibanco_plus_app/token/infraestructure/respositories/token_repository_impl.dart';

class TokenController extends GetxController {
  final storage = const FlutterSecureStorage();

  static TokenRepositoryImpl repositorio =
      TokenRepositoryImpl(PortalmfapiDatasourceImp());

  void getTokenAnonymus() async {
    final res = await repositorio.getToken(
        user: Environment.usernameAnonymous,
        password: Environment.passwordAnonymous);

    if (res != null) {
      await storage.write(key: "tokenAnonymus", value: res.accessToken);
    }
  }

  Future<bool> getTokenUser(String user, String password) async {
    final res = await repositorio.getToken(user: user, password: password);
    if (res != null) {
      final userCtrl = Get.find<UserController>();
      await storage.write(key: "tokenUser", value: res.accessToken);
      await storage.write(key: "tokenRefresh", value: res.refreshToken);
      await storage.write(key: "user", value: user);
      userCtrl.userEmail.value = user;
      userCtrl.isLogged.value = true;
      return true;
    }
    return false;
  }

  Future<bool?> refreshToken() async {
    final tokenRefresh = await storage.read(key: "tokenRefresh");
    if (tokenRefresh == null) return null;
    final token = await repositorio.refreshToken(refreshToken: tokenRefresh);
    if (token != null) {
      final userCtrl = Get.find<UserController>();
      await storage.write(key: "tokenUser", value: token.accessToken);
      await storage.write(key: "tokenRefresh", value: token.refreshToken);
      userCtrl.isLogged.value = true;
      return true;
    } else {
      return false;
    }
  }
}

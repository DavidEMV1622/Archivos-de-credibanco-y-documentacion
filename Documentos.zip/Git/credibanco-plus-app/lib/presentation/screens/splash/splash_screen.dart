import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late Timer ruteo;
  @override
  void initState() {
    super.initState();
    ruteo = Timer.periodic(const Duration(seconds: 3), (timer) {
      context.go("/home");
      ruteo.cancel();
    });
  }

  @override
  void dispose() {
    ruteo.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: SizedBox(
        width: size.width,
        height: size.height,
        key: GlobalKey(),
        child: TweenAnimationBuilder<double>(
            tween: Tween(begin: -380, end: 0),
            duration: const Duration(milliseconds: 3000),
            curve: Curves.easeOutExpo,
            builder: (context, value, child) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(height: size.width * 0.30),
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Transform.translate(
                        offset: Offset(0, (value / 3) * -1),
                        child: SvgPicture.asset("assets/icons/logo_splash.svg"),
                      ),
                      Positioned(
                        top: 20,
                        child: Container(
                          color: Colors.red,
                          height: 120,
                        ),
                      ),
                    ],
                  ),
                  Transform.translate(
                    offset: Offset(0, value * -1),
                    child: SvgPicture.asset("assets/icons/logo_splash2.svg",
                        width: size.width),
                  ),
                ],
              );
            }),
      ),
    );
  }
}

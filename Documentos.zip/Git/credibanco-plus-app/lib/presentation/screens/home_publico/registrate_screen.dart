import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/presentation/controllers/merchant_controller.dart';
import 'package:credibanco_plus_app/presentation/controllers/token_controller.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

class RegistrateScreen extends StatefulWidget {
  const RegistrateScreen({super.key});

  @override
  State<RegistrateScreen> createState() => _RegistrateScreenState();
}

class _RegistrateScreenState extends State<RegistrateScreen> {
  @override
  void initState() {
    super.initState();
    Get.put(TokenController().getTokenAnonymus());
    Get.put(_FormState());
  }

  @override
  void dispose() {
    Get.delete<TokenController>();
    Get.delete<_FormState>();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: CustomBackButtom(onPressed: () {
          context.pushReplacement("/login");
        }),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding:
              EdgeInsets.only(left: 25, right: 25, top: size.height * 0.02),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Regístrate",
                style: gilroyBold.copyWith(color: colorVerde),
              ),
              const SizedBox(height: 12),
              const Text(
                "Para registrarte, debemos identificar tu comercio. Ingresa tu cédula o NIT para verificarlo. ",
                style: gilroyRegular,
              ),
              const SizedBox(height: 16),
              const _FormNit()
            ],
          ),
        ),
      ),
      persistentFooterButtons: const [RegisterButton()],
    );
  }
}

class RegisterButton extends StatelessWidget {
  const RegisterButton({super.key});

  @override
  Widget build(BuildContext context) {
    final fomrCtrl = Get.find<_FormState>();
    return Obx(
      () => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: ButtonPrimary(
          textButton: "Continuar",
          isActive: fomrCtrl.isvalidnit.value!,
          onpressParam: () async {
            // todo
            // usuarioExisteModal(context);
            FocusManager.instance.primaryFocus?.unfocus();
            final res = await MerchantController.validateNit(
                fomrCtrl.nitController.value!.text);
            if (res == null) {
              if (context.mounted) nitNoEncontrado(context);
            } else {
              if (context.mounted) {
                context.pushReplacement("/password/${res.email}");
              }
            }
          },
        ),
      ),
    );
  }
}

class _FormNit extends StatelessWidget {
  const _FormNit();

  @override
  Widget build(BuildContext context) {
    final fomrCtrl = Get.put(_FormState());
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          flex: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Ingresa tu cédula o NIT",
                style: gilroyBold16.copyWith(fontSize: 14, color: colorNegro),
              ),
              const SizedBox(height: 6),
              Obx(() => CustomInput(
                    placeholder: "",
                    textController: fomrCtrl.nitController.value!,
                    isOk: fomrCtrl.isvalidnit.value!,
                    textInputType: TextInputType.number,
                    inputFormatters: [
                      LengthLimitingTextInputFormatter(15),
                      FilteringTextInputFormatter.allow(RegExp('[0-9]')),
                    ],
                    onchage: (nit) {
                      final bool valid =
                          (nit == null || nit == "") ? false : true;
                      if (valid == fomrCtrl.isvalidnit.value!) return "";
                      fomrCtrl.isvalidnit.value = valid;
                      return "";
                    },
                    validator: (nit) {
                      return (nit == null || nit == "") ? "" : null;
                    },
                  )),
              const SizedBox(height: 7),
              Text(
                "Sin dígito de verificación",
                style: gilroyRegular.copyWith(fontSize: 12, color: colorNegro),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class _FormState extends GetxController {
  final isvalidDv = Rxn<bool>(false);
  final isvalidnit = Rxn<bool>(false);
  final nitController = Rxn<TextEditingController>(TextEditingController());
}

void usuarioExisteModal(BuildContext context) {
  final size = MediaQuery.of(context).size;
  showGeneralDialog(
    context: context,
    barrierLabel: "Barrier",
    barrierDismissible: true,
    barrierColor: const Color.fromRGBO(0, 175, 170, 0.8),
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (_, __, ___) {
      return Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          height: size.height * 0.5,
          child: Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 18),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SvgPicture.asset("assets/icons/alerta.svg"),
                  const SizedBox(height: 15),
                  const Text(
                      "El usuario ya se encuentra registrado en nuestro sistema. Por favor inicia sesión para continuar.",
                      style: gilroyRegular,
                      textAlign: TextAlign.center),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(children: [
                      const TextSpan(
                          text: " Si olvidaste tu contraseña ",
                          style: gilroyRegular),
                      TextSpan(
                          text: "recuperala aquí.",
                          style: gilroyBold16.copyWith(color: colorAzul)),
                    ]),
                  ),
                  const SizedBox(height: 15),
                  ButtonPrimary(
                    textButton: "Volver",
                    onpressParam: () {
                      context.pop();
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (_, anim, __, child) {
      Tween<Offset> tween;
      if (anim.status == AnimationStatus.reverse) {
        tween = Tween(begin: const Offset(-1, 0), end: Offset.zero);
      } else {
        tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
      }

      return SlideTransition(
        position: tween.animate(anim),
        child: FadeTransition(
          opacity: anim,
          child: child,
        ),
      );
    },
  );
}

void nitNoEncontrado(BuildContext context) {
  showGeneralDialog(
    context: context,
    barrierLabel: "Barrier",
    barrierDismissible: true,
    barrierColor: const Color.fromRGBO(0, 175, 170, 0.8),
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (_, __, ___) {
      return Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          constraints: const BoxConstraints(maxHeight: 300),
          child: Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SvgPicture.asset("assets/icons/alerta.svg", height: 114),
                  const SizedBox(height: 18),
                  Text("NIT no encontrado",
                      style: gilroyRegular.copyWith(fontSize: 16),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 15),
                  RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(children: [
                      TextSpan(
                          text: "Afíliate ",
                          style: gilroyRegular.copyWith(fontSize: 16)),
                      TextSpan(
                        text: "aquí.",
                        style: gilroyBold16.copyWith(
                            color: Colors.transparent,
                            fontSize: 16,
                            shadows: [
                              const Shadow(
                                  offset: Offset(0, -2), color: colorAzul)
                            ],
                            decoration: TextDecoration.underline,
                            decorationStyle: TextDecorationStyle.dashed,
                            decorationColor: colorAzul,
                            decorationThickness: 1),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 18),
                  ButtonPrimary(
                    textButton: "Volver",
                    onpressParam: () {
                      context.pop();
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (_, anim, __, child) {
      Tween<Offset> tween;
      if (anim.status == AnimationStatus.reverse) {
        tween = Tween(begin: const Offset(-1, 0), end: Offset.zero);
      } else {
        tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
      }

      return SlideTransition(
        position: tween.animate(anim),
        child: FadeTransition(
          opacity: anim,
          child: child,
        ),
      );
    },
  );
}

import 'dart:convert';
import 'package:flutter_svg/svg.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/helpers/helpers.dart';
import 'package:credibanco_plus_app/presentation/controllers/biometrics_controller.dart';
import 'package:credibanco_plus_app/presentation/controllers/token_controller.dart';
import 'package:credibanco_plus_app/presentation/screens/modals/modals.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  void initState() {
    biometricdisabled();
    super.initState();
  }

  void biometricdisabled() async {
    final biometricsController = Get.put(BiometricsController());
    if (await biometricsController.getisDisabled() == true) {
      final activar = await fadeInRigthTransition(context, ActivarHuellaPopUp(),
          barrierDismissible: false);
      if (activar) openAppSettings();
    }
  }

  @override
  Widget build(BuildContext context) {
    Get.delete<_FormLoginController>();
    Get.delete<NavigationBottomController>();
    final formLoginController = Get.put(_FormLoginController());
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    final validationKey = GlobalKey<FormState>();
    final biometricsController = Get.find<BiometricsController>();

    return Scaffold(
      appBar: AppBar(
        leading: CustomBackButtom(
          onPressed: () => context.pushReplacement("/home"),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.only(left: 27, right: 27),
          child: Form(
            key: validationKey,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SvgPicture.asset("assets/img/logo_credibanco_login.svg"),
                  const SizedBox(
                    height: 87,
                  ),
                  const Text('Inicia sesión', style: gilroyBold24),
                  const SizedBox(
                    height: 77,
                  ),
                  Obx(
                    () => CustomInput(
                      placeholder: "Correo electrónico",
                      isError: formLoginController.isError.value!,
                      textController: emailController,
                      onchage: (p0) {
                        if (formLoginController.isError.value! == true) {
                          formLoginController.isError.value = false;
                        }
                        return "";
                      },
                    ),
                  ),
                  const SizedBox(height: 8),
                  Obx(
                    () => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomInput(
                            placeholder: "Contraseña",
                            isError: formLoginController.isError.value!,
                            textController: passwordController,
                            contentPadding:
                                const EdgeInsets.only(top: 20, left: 15),
                            isPassword: formLoginController.hidePassword.value!,
                            suffixIcon: IconButton(
                              onPressed: () {
                                formLoginController.hidePassword.value =
                                    !formLoginController.hidePassword.value!;
                              },
                              icon: formLoginController.hidePassword.value!
                                  ? SvgPicture.asset(
                                      "assets/icons/hide_password.svg")
                                  : SvgPicture.asset(
                                      "assets/icons/show_password.svg"),
                            )),
                        const SizedBox(height: 5),
                        if (formLoginController.isError.value!)
                          Text(
                            "*Credenciales inválidas",
                            style: gilroyRegular.copyWith(
                                fontSize: 10, color: colorRojo),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  ButtonPrimary(
                    textButton: "Iniciar sesión",
                    onpressParam: () {
                      login(emailController.text, passwordController.text,
                          context);
                    },
                  ),
                  Obx(() => biometricsController.canAuth.value!
                      ? AuthBio(
                          titulo: "Ingresa con huella",
                          isError: biometricsController.isError.value!,
                          msgError: biometricsController.msgError.value!,
                          onPressed: () async {
                            biometricsController.isError.value = false;
                            final authResult =
                                await biometricsController.autenticar();
                            if (authResult) {
                              final res = await biometricAuth(context);
                              if (res == null) {
                                biometricsController.isError.value = true;
                                biometricsController.msgError.value =
                                    "Para activar la huella debes ingresar con usuario y contraseña";
                              } else if (res) {
                                context.pushReplacement('/home_user');
                              } else {
                                formLoginController.isError.value = true;
                              }
                            }
                          },
                        )
                      : const SizedBox()),
                  ButtonSecondary(
                    textButton: "Regístrate",
                    onpressParam: () {
                      context.push('/registrate');
                    },
                  ),
                  const SizedBox(height: 22),
                  InkWell(
                    onTap: () {},
                    child: Text(
                      "Olvidé mi contraseña",
                      style: gilroyLight.copyWith(
                          color: Colors.transparent,
                          shadows: [
                            const Shadow(
                                offset: Offset(0, -2), color: colorAzul)
                          ],
                          decoration: TextDecoration.underline,
                          decorationStyle: TextDecorationStyle.solid,
                          decorationColor: colorAzul,
                          decorationThickness: 1),
                    ),
                  ),
                  const SizedBox(height: 22)
                ]),
          ),
        ),
      ),
      persistentFooterAlignment: AlignmentDirectional.center,
      persistentFooterButtons: [
        Container(
            margin: const EdgeInsets.only(bottom: 16),
            child: const Text(
              "Ver 1.0.0.8-RC",
              style: TextStyle(fontSize: 8, color: Color(0XFF58595B)),
            ))
      ],
    );
  }

  void login(String email, String password, BuildContext context) async {
    final formLoginController = Get.find<_FormLoginController>();
    FocusManager.instance.primaryFocus?.unfocus();
    final tokenCtrl = Get.put(TokenController());

    final isLoginOk = await tokenCtrl.getTokenUser(
        email, base64.encode(utf8.encode(password)));

    formLoginController.isError.value = !isLoginOk;
    if (isLoginOk) context.pushReplacement('/home_user');
  }

  Future<bool?> biometricAuth(BuildContext context) async {
    final tokenCtrl = Get.put(TokenController());
    return await tokenCtrl.refreshToken();
  }
}

class _FormLoginController extends GetxController {
  final isError = Rxn<bool>(false);
  final hidePassword = Rxn<bool>(true);
}

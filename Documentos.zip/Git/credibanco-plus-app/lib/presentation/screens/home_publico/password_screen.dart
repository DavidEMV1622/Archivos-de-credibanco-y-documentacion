import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/helpers/alertas.dart';
import 'package:credibanco_plus_app/presentation/controllers/terms_controller.dart';
import 'package:credibanco_plus_app/presentation/screens/modals/modals.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';

class PasswordScreen extends StatefulWidget {
  final String email;
  const PasswordScreen({super.key, required this.email});

  @override
  State<PasswordScreen> createState() => _PasswordScreenState();
}

class _PasswordScreenState extends State<PasswordScreen> {
  @override
  void initState() {
    Get.delete<_FormPassWord>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final formCtrl = Get.put(_FormPassWord());
    final size = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBar(leading: CustomBackButtom(
          onPressed: () {
            context.pushReplacement('/registrate');
            Get.delete<_FormPassWord>();
          },
        )),
        body: Padding(
          padding:
              EdgeInsets.only(left: 25, right: 24, top: size.height * 0.02),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Crea una contraseña",
                style: gilroyBold.copyWith(color: colorVerde),
              ),
              const SizedBox(height: 12),
              const Text(
                "Con esta contraseña podrás ingresar a la aplicación.",
                style: gilroyRegular,
              ),
              const SizedBox(height: 16),
              Obx(
                () => CustomInput(
                    isOk: formCtrl.passWordOk() == "" ? false : true,
                    placeholder: "Contraseña",
                    contentPadding: const EdgeInsets.only(top: 30, left: 15),
                    isPassword: formCtrl.hidepass1.value!,
                    onTap: () {
                      formCtrl.isVisibleCard.value = true;
                    },
                    onTapOutside: (p0) {
                      formCtrl.isVisibleCard.value = false;
                    },
                    suffixIcon: IconButton(
                        onPressed: () {
                          formCtrl.hidepass1.value = !formCtrl.hidepass1.value!;
                        },
                        icon: formCtrl.hidepass1.value!
                            ? SvgPicture.asset("assets/icons/hide_password.svg")
                            : SvgPicture.asset(
                                "assets/icons/show_password.svg")),
                    onchage: (pass) {
                      formCtrl.password.value = pass ?? "";
                      return "";
                    },
                    textController: formCtrl.passCtrl),
              ),
              const _InputsPassword(),
            ],
          ),
        ),
        persistentFooterButtons: [
          Obx(
            () => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: ButtonPrimary(
                textButton: "Continuar",
                isActive: formCtrl.samePasswords() &&
                    formCtrl.isCheckedTermsAndPolician(),
                onpressParam: () async {
                  await fadeInRigthTransition(
                      context, EnviaCorreoOTpPasword(email: widget.email));
                  formCtrl.isVisibleCard.value = false;
                  // context.push("/password");
                },
              ),
            ),
          )
        ]);
  }
}

class _InputsPassword extends StatelessWidget {
  const _InputsPassword();

  @override
  Widget build(BuildContext context) {
    final formCtrl = Get.find<_FormPassWord>();
    final size = MediaQuery.of(context).size;
    return SizedBox(
      height: size.height * 0.3,
      child: Stack(
        children: [
          Obx(
            () => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: CustomInput(
                      contentPadding: const EdgeInsets.only(top: 30, left: 15),
                      isOk: formCtrl.samePasswords(),
                      isPassword: formCtrl.hidepass2.value!,
                      onTap: () {
                        formCtrl.isVisibleCard.value = false;
                      },
                      onchage: (p0) {
                        formCtrl.repassword.value = p0 ?? "";
                        formCtrl.samepass.value = formCtrl.repassword.value ==
                            formCtrl.password.value;
                        return "";
                      },
                      suffixIcon: IconButton(
                          onPressed: () {
                            formCtrl.hidepass2.value =
                                !formCtrl.hidepass2.value!;
                          },
                          icon: formCtrl.hidepass2.value!
                              ? SvgPicture.asset(
                                  "assets/icons/hide_password.svg")
                              : SvgPicture.asset(
                                  "assets/icons/show_password.svg")),
                      validator: (p0) {
                        return (formCtrl.password.value! == p0 && p0 != "")
                            ? null
                            : "";
                      },
                      placeholder: "Confirmar contraseña",
                      textController: formCtrl.passCtrl2),
                ),
                const SizedBox(height: 12),
                (formCtrl.password.value! != formCtrl.repassword.value &&
                        formCtrl.repassword.value != "")
                    ? Text(
                        "*Las contraseñas no coinciden",
                        style: gilroyRegular.copyWith(
                            fontSize: 12, color: colorRojo),
                      )
                    : const SizedBox(),
              ],
            ),
          ),
          Obx(
            () => Positioned(
              top: (formCtrl.password.value! != formCtrl.repassword.value &&
                      formCtrl.repassword.value != "")
                  ? 85
                  : 60,
              left: -10,
              child: _CheckTerminos(formCtrl: formCtrl),
            ),
          ),
          Obx(() => Positioned(
                top: (formCtrl.password.value! != formCtrl.repassword.value &&
                        formCtrl.repassword.value != "")
                    ? 135
                    : 105,
                left: -10,
                child: _CheckPoliticas(formCtrl: formCtrl, size: size),
              )),
          Obx(() => formCtrl.isVisibleCard.value!
              ? const _CardPasswRecommendations()
              : const SizedBox()),
        ],
      ),
    );
  }
}

class _CheckTerminos extends StatelessWidget {
  const _CheckTerminos({
    required this.formCtrl,
  });

  final _FormPassWord formCtrl;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Obx(
          () => Checkbox(
            value: formCtrl.isChekedTerms.value,
            onChanged: (value) async {
              formCtrl.isChekedTerms.value = value;
            },
            activeColor: colorAzul,
            checkColor: Colors.white,
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("He leído, entendido y acepto los ",
                style: gilroyRegular.copyWith(fontSize: 12)),
            InkWell(
              onTap: () async {
                await TermsController.acceptTerms(
                    "term-and-conditions-canalAppV", "lisseth.11@yopmail.com");
                return;
                final terms = await TermsController.getTerms(
                    "term-and-conditions-canalAppV1");
                if (context.mounted) {
                  final result = await Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) {
                        return FullModalScreen(
                          titulo: terms.titulo,
                          content: terms.content,
                        );
                      },
                    ),
                  );
                  if (result == true && !formCtrl.isChekedTerms.value!) {
                    formCtrl.isChekedTerms.value = true;
                  }
                }
              },
              child: Text(
                "Términos y condiciones.",
                style: gilroyBold16.copyWith(
                    color: Colors.transparent,
                    fontSize: 12,
                    shadows: [
                      const Shadow(offset: Offset(0, -2), color: colorAzul)
                    ], // Step 3 SEE HERE
                    decoration: TextDecoration.underline,
                    decorationStyle: TextDecorationStyle.solid,
                    decorationColor: colorAzul,
                    decorationThickness: 1),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _CheckPoliticas extends StatelessWidget {
  const _CheckPoliticas({
    required this.formCtrl,
    required this.size,
  });

  final _FormPassWord formCtrl;
  final Size size;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Obx(
          () => Checkbox(
            value: formCtrl.isChekedPoliticas.value,
            onChanged: (value) {
              formCtrl.isChekedPoliticas.value = value;
            },
            activeColor: colorAzul,
            checkColor: Colors.white,
          ),
        ),
        SizedBox(
          width: size.width - 80,
          child: RichText(
            textAlign: TextAlign.start,
            text: TextSpan(children: [
              TextSpan(
                  text: "He leído, entendido y acepto las ",
                  style: gilroyRegular.copyWith(fontSize: 12)),
              TextSpan(
                  recognizer: TapGestureRecognizer()
                    ..onTap = () async {
                      final terms = await TermsController.getTerms(
                          "policy-data-treatment-canalAppV1");
                      if (context.mounted) {
                        final result = await Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (BuildContext context) {
                              return FullModalScreen(
                                titulo: terms.titulo,
                                content: terms.content,
                              );
                            },
                          ),
                        );
                        if (result == true && !formCtrl.isChekedTerms.value!) {
                          formCtrl.isChekedPoliticas.value = true;
                        }
                      }
                    },
                  text:
                      "Políticas de protección y tratamiento de datos personales de Credibanco S.A.",
                  style: gilroyBold16.copyWith(
                      color: Colors.transparent,
                      fontSize: 12,
                      shadows: [
                        const Shadow(offset: Offset(0, -2), color: colorAzul)
                      ], // Step 3 SEE HERE
                      decoration: TextDecoration.underline,
                      decorationStyle: TextDecorationStyle.solid,
                      decorationColor: colorAzul,
                      decorationThickness: 1)),
            ]),
          ),
        )
      ],
    );
  }
}

class _CardPasswRecommendations extends StatelessWidget {
  const _CardPasswRecommendations();

  @override
  Widget build(BuildContext context) {
    final formCtrl = Get.find<_FormPassWord>();

    return Positioned(
        top: 2,
        right: 1,
        child: Container(
          padding:
              const EdgeInsets.only(left: 12, top: 16, right: 22, bottom: 13),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(5),
              boxShadow: const [
                BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.1),
                    offset: Offset(1, 22),
                    blurRadius: 44,
                    spreadRadius: 0)
              ]),
          child: Obx(
            () => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Debe tener al menos",
                  style: gilroyBold16.copyWith(color: colorNegro, fontSize: 14),
                ),
                const SizedBox(height: 10),
                CheckBoxTile(
                  title: '8 Cáracteres',
                  value: formCtrl.islength(),
                ),
                const SizedBox(height: 13),
                CheckBoxTile(title: '1 Mayúscula', value: formCtrl.hasMayus()),
                const SizedBox(height: 13),
                CheckBoxTile(
                    title: '1 Número de 0 a 9', value: formCtrl.hasNumber()),
                const SizedBox(height: 13),
                CheckBoxTile(
                    title: '1 Carácter especial',
                    value: formCtrl.hasSpecialCharacter()),
              ],
            ),
          ),
        ));
  }
}

class _FormPassWord extends GetxController {
  final password = Rxn<String>("");
  final repassword = Rxn<String>("");
  final isVisibleCard = Rxn<bool>(false);
  final TextEditingController passCtrl = TextEditingController();
  final TextEditingController passCtrl2 = TextEditingController();
  final samepass = Rxn<bool>(true);
  final hidepass1 = Rxn<bool>(true);
  final hidepass2 = Rxn<bool>(true);
  final RegExp _numberegex = RegExp("[0-9]");
  final RegExp _mayusregex = RegExp("[A-Z]");
  final RegExp _charactedregex = RegExp("[*@.#¡!=]");

  final isChekedTerms = Rxn<bool>(false);
  final isChekedPoliticas = Rxn<bool>(false);

  bool islength() {
    return password.value!.length >= 8;
  }

  bool hasNumber() {
    return _numberegex.hasMatch(password.value!);
  }

  bool hasMayus() {
    return _mayusregex.hasMatch(password.value!);
  }

  bool hasSpecialCharacter() {
    return _charactedregex.hasMatch(password.value!);
  }

  String? passWordOk() {
    return (islength() && hasNumber() && hasMayus() && hasSpecialCharacter())
        ? null
        : "";
  }

  bool samePasswords() {
    bool isPassok = passWordOk() == "" ? false : true;

    if (!isPassok) return false;

    return password.value == repassword.value;
  }

  bool isCheckedTermsAndPolician() {
    return isChekedPoliticas.value! && isChekedTerms.value!;
  }
}

void enviarOtp(BuildContext context) {}

void alertaActualizaTusDatos() {}

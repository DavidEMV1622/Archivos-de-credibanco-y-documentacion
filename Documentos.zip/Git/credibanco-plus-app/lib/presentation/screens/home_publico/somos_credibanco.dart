import 'package:flutter/material.dart';

class SomosCredibancoScreen extends StatelessWidget {
   
  const SomosCredibancoScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
         child: Text('SomosCredibancoScreen'),
      ),
    );
  }
}
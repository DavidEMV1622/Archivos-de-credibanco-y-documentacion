import 'package:credibanco_plus_app/helpers/number_formats.dart';
import 'package:credibanco_plus_app/presentation/controllers/user_controller.dart';
import 'package:credibanco_plus_app/presentation/screens/home_publico/controllers/calc_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CalcController());
    final bottonCtrl = Get.put(NavigationBottomController());
    final size = MediaQuery.sizeOf(context);
    return SafeArea(
      child: Scaffold(
        key: bottonCtrl.keyScaffold.value,
        drawer: const _HomeSideMenu(),
        onDrawerChanged: (isOpened) {
          if (!isOpened) bottonCtrl.currentIndex.value = 0;
        },
        body: SizedBox(
          height: size.height,
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _HeaderHome(),
              _BienvenidoContainer(),
              _ValorVenta(),
              Expanded(
                child: SizedBox(),
              ),
              Calculadora(),
              SizedBox(height: 21),
            ],
          ),
        ),
        bottomNavigationBar: const HomeBottomNavigationbar(),
      ),
    );
  }
}

class _ValorVenta extends StatefulWidget {
  const _ValorVenta();

  @override
  State<_ValorVenta> createState() => _ValorVentaState();
}

class _ValorVentaState extends State<_ValorVenta> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final calcController = Get.find<CalcController>();
    return Container(
      color: Colors.white,
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.15),
      height: size.height * 0.15,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 15),
          Text(
            "Valor de la venta",
            style: gilroyBold.copyWith(fontSize: 20, color: colorVerde),
          ),
          Expanded(child: Container()),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const SizedBox(
                width: 30,
              ),
              Expanded(
                child: Obx(
                  () => TextFormField(
                    readOnly: true,
                    textDirection: TextDirection.ltr,
                    controller: calcController.inputValorCtrl.value,
                    scrollController: calcController.scrollController.value,
                    enableSuggestions: false,
                    enableInteractiveSelection: false,
                    scrollPadding: EdgeInsets.zero,
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        suffixIcon:
                            calcController.inputValorCtrl.value!.text != "\$ 0"
                                ? IconButton(
                                    onPressed: () => calcController.funDel(),
                                    icon: Image.asset(
                                      "assets/icons/delete_icon.png",
                                    ))
                                : const SizedBox(width: 35),
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none),
                    textAlign: TextAlign.center,
                    style: gilroyBold.copyWith(
                        fontSize: 32,
                        color: const Color.fromRGBO(37, 37, 37, 0.8)),
                  ),
                ),
              ),
            ],
          ),
          Obx(() => calcController.isSum.value!
              ? SizedBox(
                  width: double.infinity,
                  height: 28,
                  child: Text(
                    "= \$ ${NumberFormats.currencyFormat(calcController.totalSum.value!)}",
                    textAlign: TextAlign.start,
                    style: gilroyBold.copyWith(
                        fontSize: 20,
                        color: const Color.fromRGBO(37, 37, 37, 0.4)),
                  ),
                )
              : const SizedBox(
                  height: 28,
                )),
          const Divider(
            height: 0,
            color: Color.fromRGBO(37, 37, 37, 0.5),
          ),
        ],
      ),
    );
  }
}

class _BienvenidoContainer extends StatelessWidget {
  const _BienvenidoContainer();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return SizedBox(
      height: size.height * 0.12,
      width: double.infinity,
      child: Stack(
        children: [
          const _Bienvenido(),
          Positioned(
            top: size.height * 0.09,
            right: 23.89,
            child: Container(
              decoration: BoxDecoration(
                  color: colorAmarillo,
                  borderRadius: BorderRadius.circular(50)),
              height: 16,
              width: 16,
            ),
          ),
        ],
      ),
    );
  }
}

class _Bienvenido extends StatelessWidget {
  const _Bienvenido();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final userCtrl = Get.find<UserController>();

    return Container(
      width: double.infinity,
      height: size.height * 0.10,
      decoration: const BoxDecoration(color: Color.fromRGBO(0, 175, 170, 0.1)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Obx(
            () => Text(
              userCtrl.isLogged.value!
                  ? "Hola, ${userCtrl.userEmail}"
                  : "¡Bienvenido!",
              style: gilroyBold.copyWith(fontSize: 16, color: colorVerde),
            ),
          ),
          Text(
            "Recibe pagos con billeteras y mucho más",
            style: gilroyBold.copyWith(fontSize: 16, color: colorVerde),
          )
        ],
      ),
    );
  }
}

class _HeaderHome extends StatelessWidget {
  const _HeaderHome();

  @override
  Widget build(BuildContext context) {
    final userCtrl = Get.find<UserController>();
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: const BoxDecoration(color: Colors.white, boxShadow: [
        BoxShadow(
            color: Color.fromRGBO(63, 63, 68, 0.05),
            blurRadius: 2,
            spreadRadius: 0,
            offset: Offset(0, 2))
      ]),
      child: Obx(
        () => Row(
          mainAxisAlignment: userCtrl.isLogged.value!
              ? MainAxisAlignment.center
              : MainAxisAlignment.spaceBetween,
          children: [
            SvgPicture.asset("assets/img/logo_credibanco_login.svg"),
            if (!userCtrl.isLogged.value!)
              SizedBox(
                height: 32,
                child: FilledButton(
                    onPressed: () {
                      context.pushReplacement('/login');
                    },
                    style: ButtonStyle(
                        padding: const MaterialStatePropertyAll(
                            EdgeInsets.symmetric(horizontal: 16)),
                        backgroundColor:
                            const MaterialStatePropertyAll(colorAzul),
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)))),
                    child: Row(
                      children: [
                        Text(
                          "Inicia sesión",
                          style: gilroyBold16.copyWith(
                              fontSize: 12, color: Colors.white),
                        ),
                        const SizedBox(width: 9),
                        SvgPicture.asset("assets/icons/icon_key.svg")
                      ],
                    )),
              )
          ],
        ),
      ),
    );
  }
}

class _HomeSideMenu extends StatelessWidget {
  const _HomeSideMenu();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: double.infinity,
      backgroundColor: Colors.white,
      child: SafeArea(
          child: Container(
              height: double.infinity,
              color: Colors.white,
              child: Column(children: [
                const _HeaderHome(),
                const SizedBox(height: 46),
                const MainItemMenu(),
                const SizedBox(height: 46),
                InkWell(
                  onTap: () {
                    final userCtrl = Get.find<UserController>();
                    userCtrl.isLogged.value = false;
                    userCtrl.userEmail.value = null;
                    final bottonCtrl = Get.put(NavigationBottomController());
                    if (bottonCtrl
                        .keyScaffold.value!.currentState!.isDrawerOpen) {
                      bottonCtrl.keyScaffold.value!.currentState!.closeDrawer();
                    }
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                          "assets/icons/side_menu/logout_icon.svg"),
                      const SizedBox(width: 14),
                      Text(
                        "Cerrar sesión",
                        style: gilroyRegular.copyWith(
                            fontSize: 16, color: colorVerde),
                      )
                    ],
                  ),
                )
              ]))),
    );
  }
}

class MainItemMenu extends StatelessWidget {
  const MainItemMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(left: 18),
      child: Column(
        children: [
          _ExpansionTileMain(
            icon:
                SvgPicture.asset("assets/icons/side_menu/credit_card_icon.svg"),
            title: "Funciones transaccionales",
            children: [
              _LabelDrawer(
                label: "Transacciones Reversadas",
                onTap: () {},
              ),
              const SizedBox(height: 27),
              _LabelDrawer(
                label: "Realizar una anulación",
                onTap: () {},
              ),
              const SizedBox(height: 27),
              _LabelDrawer(
                label: "Histórico de transacciones",
                onTap: () {},
              ),
            ],
          ),
          _ExpansionTileMain(
            icon: SvgPicture.asset("assets/icons/side_menu/impuestos_icon.svg"),
            title: "Configura tus impuestos",
            children: const [],
            mainFcn: () {
              context.pushReplacement('/login');
            },
          ),
          _ExpansionTileMain(
            icon: SvgPicture.asset("assets/icons/side_menu/perfil_icon.svg"),
            title: "Perfil de usuario",
            children: [
              _LabelDrawer(
                label: "Cambiar contraseña",
                onTap: () {},
              ),
              const SizedBox(height: 27),
              _LabelDrawer(
                label: "Actualizar datos personales",
                onTap: () {},
              ),
              const SizedBox(height: 27),
              _LabelDrawer(
                label: "Documentos del comercio",
                onTap: () {},
              ),
            ],
          ),
          _ExpansionTileMain(
            icon: SvgPicture.asset(
                "assets/icons/side_menu/entrenamiento_icon.svg"),
            title: "Entrenamiento",
            children: const [],
            mainFcn: () {},
          ),
          _ExpansionTileMain(
            icon: SvgPicture.asset("assets/icons/side_menu/valida_icon.svg"),
            title: "Valida el ID del funcionario",
            children: const [],
            mainFcn: () {},
          ),
          _ExpansionTileMain(
            icon:
                SvgPicture.asset("assets/icons/side_menu/contactanos_icon.svg"),
            title: "Contáctanos",
            children: const [],
            mainFcn: () {},
          ),
        ],
      ),
    );
  }
}

class _ExpansionTileMain extends StatefulWidget {
  final Widget icon;
  final String title;
  final List<Widget> children;
  final void Function()? mainFcn;

  _ExpansionTileMain({
    required this.icon,
    required this.title,
    required this.children,
    this.mainFcn,
  })  : assert(!(children.isEmpty && mainFcn == null),
            "mainFcn is required when children is empty "),
        assert(!(children.isNotEmpty && mainFcn != null),
            "mainFcn is must be null when children is not empty ");

  @override
  State<_ExpansionTileMain> createState() => _ExpansionTileMainState();
}

class _ExpansionTileMainState extends State<_ExpansionTileMain> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      childrenPadding: const EdgeInsets.all(0),
      tilePadding: const EdgeInsets.symmetric(vertical: 0),
      title: SizedBox(
        height: 40,
        child: Row(
          children: [
            widget.icon,
            const SizedBox(width: 14),
            Text(widget.title, style: gilroyBold16.copyWith(color: colorVerde)),
            const Spacer(),
            widget.children.isNotEmpty
                ? Icon(
                    isExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                    color: colorVerde,
                  )
                : const SizedBox(),
          ],
        ),
      ),
      trailing: const SizedBox(),
      onExpansionChanged: (value) {
        if (widget.mainFcn != null) {
          widget.mainFcn!();
          return;
        }
        setState(() {
          isExpanded = value;
        });
      },
      children: widget.children,
    );
  }
}

class _LabelDrawer extends StatelessWidget {
  final String label;
  final void Function()? onTap;

  const _LabelDrawer({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return InkWell(
      // onTap: onTap,
      onTap: () {
        context.pushReplacement("/login");
      },
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: size.width * 0.17),
        child: Text(
          label,
          style: gilroyRegular.copyWith(fontSize: 16, color: colorVerde),
        ),
      ),
    );
  }
}

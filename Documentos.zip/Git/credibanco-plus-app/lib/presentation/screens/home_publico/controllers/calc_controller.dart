import 'package:credibanco_plus_app/helpers/number_formats.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CalcController extends GetxController {
  final inputValorCtrl =
      Rxn<TextEditingController>(TextEditingController()..text = "\$ 0");

  final scrollController = Rxn<ScrollController>(ScrollController());

  final isSum = Rxn<bool>(false);
  final totalSum = Rxn<String>("");
  void goToTextFieldEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      scrollController.value!
          .jumpTo(scrollController.value!.position.maxScrollExtent);
    });
  }

  addNumber(number) {
    if (inputValorCtrl.value!.text.contains(" 0")) {
      inputValorCtrl.value!.text =
          inputValorCtrl.value!.text.replaceFirst(" 0", " ");
    }
    if (!validateLength()) return;

    inputValorCtrl.value!.text = inputValorCtrl.value!.text + number;

    if (isSum.value!) {
      formateNumbersSum();
      suma();
    } else {
      formatNumber();
    }

    goToTextFieldEnd();
    inputValorCtrl.refresh();
  }

  formatNumber() {
    inputValorCtrl.value!.text =
        "\$ ${NumberFormats.currencyFormat(inputValorCtrl.value!.text)}";
  }

  formateNumbersSum() {
    List<String> format = [];
    List<String> numbers =
        inputValorCtrl.value!.text.replaceAll("\$ ", "").split("+");
    for (var valo in numbers) {
      format.add(NumberFormats.currencyFormat(valo));
    }

    inputValorCtrl.value!.text = format.join("+");
  }

  validateLength() {
    if (!isSum.value! &&
        inputValorCtrl.value!.text
                .replaceAll("+", "")
                .replaceAll("\$", "")
                .replaceAll(" ", "")
                .replaceAll(" ", "")
                .replaceAll(".", "")
                .length ==
            9) return false;

    return true;
  }

  funDel() {
    if (inputValorCtrl.value!.text.length == 2 && isSum.value! == false) return;
    if (inputValorCtrl.value!.text.length == 3) {
      inputValorCtrl.value!.text =
          "${isSum.value! ? '\$ 0' : ''}${inputValorCtrl.value!.text.substring(0, inputValorCtrl.value!.text.length - 1)}${isSum.value! ? '' : '0'}";

      isSum.value = inputValorCtrl.value!.text.contains("+");
      if (isSum.value!) {
        formateNumbersSum();
        suma();
      }

      inputValorCtrl.refresh();
      goToTextFieldEnd();
      return;
    }

    inputValorCtrl.value!.text = inputValorCtrl.value!.text
        .substring(0, inputValorCtrl.value!.text.length - 1);
    changeIsSum(inputValorCtrl.value!.text.contains("+"));
    if (isSum.value!) {
      formateNumbersSum();
      suma();
    } else {
      formatNumber();
    }

    inputValorCtrl.refresh();
    goToTextFieldEnd();
  }

  funAc() {
    inputValorCtrl.value!.text = "\$ 0";
    changeIsSum(false);
    inputValorCtrl.refresh();
  }

  addSum() {
    if (inputValorCtrl.value!.text.endsWith("+") ||
        inputValorCtrl.value!.text == "\$ 0") return;

    changeIsSum(true);
    inputValorCtrl.value!.text =
        "${inputValorCtrl.value!.text.replaceAll("\$", "")}+";
    suma();
    inputValorCtrl.refresh();
    goToTextFieldEnd();
  }

  changeIsSum(bool boolSum) {
    isSum.value = boolSum;
    if (boolSum) return;
    totalSum.value = "";
    if (inputValorCtrl.value!.text.contains("\$")) return;
    inputValorCtrl.value!.text = "\$${inputValorCtrl.value!.text}";
  }

  suma() {
    final List<String> valores = inputValorCtrl.value!.text
        .replaceAll("\$", "")
        .trim()
        .replaceAll(".", "")
        .split("+");
    int total = 0;
    for (var val in valores) {
      if (val == "") continue;
      total += int.parse(val);
    }
    if (total > 999999999) return funDel();
    totalSum.value = total.toString();
  }
}

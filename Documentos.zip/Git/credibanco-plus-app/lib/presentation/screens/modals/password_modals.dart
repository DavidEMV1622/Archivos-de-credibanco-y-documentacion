import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:pinput/pinput.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/config/theme/app_theme.dart';
import 'package:credibanco_plus_app/helpers/helpers.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';

class EnviaCorreoOTpPasword extends StatelessWidget {
  final String email;
  const EnviaCorreoOTpPasword({super.key, required this.email});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 365),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 22),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const SizedBox(height: 23),
                SvgPicture.asset("assets/icons/email_icon.svg", height: 90),
                const SizedBox(height: 13),
                Text(
                    "Este es el correo con el que podrás ingresar a la aplicación:",
                    style: gilroyRegular.copyWith(fontSize: 16),
                    textAlign: TextAlign.center),
                Text(hideEmail(email),
                    style: gilroyBold.copyWith(fontSize: 14, color: colorNegro),
                    textAlign: TextAlign.center),
                const SizedBox(height: 13),
                Text("¿Deseas actualizar tus datos?",
                    style: gilroyBold.copyWith(fontSize: 14, color: colorNegro),
                    textAlign: TextAlign.center),
                const Expanded(child: SizedBox()),
                ButtonPrimary(
                  textButton: "Continuar con ese correo",
                  onpressParam: () async {
                    final res = await fadeInRigthTransition(
                        context, OtpPopUp(email: email));
                    context.pop(res);
                  },
                ),
                ButtonSecondary(
                    textButton: "Actualizar datos",
                    onpressParam: () {
                      context.pop(123);
                      fadeInRigthTransition(context, const ActualizaTusDatos());
                    }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ActualizaTusDatos extends StatelessWidget {
  const ActualizaTusDatos({super.key});

  Future<void> _launchUrl(url) async {
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    var gilroyRegularTmp = gilroyRegular.copyWith(fontSize: 14);
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 458),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 22),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SvgPicture.asset("assets/icons/alerta.svg", height: 90),
                const SizedBox(height: 46),
                Text("¡Actualiza tus datos!",
                    style: gilroyBold16.copyWith(
                        fontSize: 18, color: Colors.black),
                    textAlign: TextAlign.center),
                InkWell(
                  onTap: () {
                    _launchUrl(
                        Uri.parse('mailto:novedades@incocredito.com.co'));
                  },
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(children: [
                      TextSpan(
                          text: "Para ello envía un mail a ",
                          style: gilroyRegularTmp),
                      TextSpan(
                          text: "novedades@incocredito.com.co",
                          style: gilroyBold16.copyWith(
                              color: Colors.transparent,
                              fontSize: 14,
                              shadows: [
                                const Shadow(
                                    offset: Offset(0, -1), color: colorAzul)
                              ],
                              decoration: TextDecoration.underline,
                              decorationStyle: TextDecorationStyle.solid,
                              decorationColor: colorAzul,
                              decorationThickness: 1)),
                      TextSpan(text: " con:", style: gilroyRegularTmp),
                    ]),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "1. Cámara de comercio o RUT.",
                  style: gilroyRegularTmp,
                  textAlign: TextAlign.center,
                ),
                Text("2. Datos a actualizar (correo y/o celular).",
                    textAlign: TextAlign.center, style: gilroyRegularTmp),
                Text(
                    "3. Si tienes un nuevo representante legal adjunta su cédula.",
                    textAlign: TextAlign.center,
                    style: gilroyRegularTmp),
                const SizedBox(height: 15),
                Text(
                    " Recuerda que esta autenticación solo puede realizarla el representante legal",
                    textAlign: TextAlign.center,
                    style:
                        gilroyBold.copyWith(fontSize: 14, color: Colors.black)),
                const SizedBox(height: 20),
                ButtonPrimary(
                  textButton: "Cerrar",
                  onpressParam: () {
                    context.pop();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class OtpPopUp extends StatefulWidget {
  final String email;
  const OtpPopUp({super.key, required this.email});

  @override
  State<OtpPopUp> createState() => _OtpPopUpState();
}

class _OtpPopUpState extends State<OtpPopUp> {
  bool isError = false;
  final TextEditingController _pinEditingController = TextEditingController();

  String getNextDate() {
    final date = DateTime.now().add(const Duration(days: 1));
    return "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}";
  }

  void resertPin() {
    setState(() {
      isError = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 360),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 17),
            child: Column(
              children: [
                !isError
                    ? Text(
                        "Enviamos un código al correo ${hideEmail(widget.email)}",
                        textAlign: TextAlign.center,
                        style: gilroyBold.copyWith(color: Colors.black),
                      )
                    : Text(
                        "Código incorrecto",
                        textAlign: TextAlign.center,
                        style: gilroyBold.copyWith(color: colorRojo),
                      ),
                const SizedBox(height: 10),
                if (!isError)
                  Text(
                    "Ingresa el código.",
                    style: gilroyRegular.copyWith(fontSize: 12),
                  ),
                const SizedBox(height: 11),
                Text(
                  "Te recomendamos revisar en la carpeta de correos no deseados",
                  style: gilroyRegular.copyWith(fontSize: 10),
                ),
                const SizedBox(
                  height: 9,
                ),
                Pinput(
                  length: 6,
                  controller: _pinEditingController,
                  onChanged: (value) => resertPin(),
                  defaultPinTheme: AppTheme().getDefaultPinTheme(),
                  submittedPinTheme: isError
                      ? AppTheme().getErrorPinTheme()
                      : AppTheme().getSubmittPinTheme(),
                  errorPinTheme: AppTheme().getErrorPinTheme(),
                ),
                const SizedBox(
                  height: 10,
                ),
                !isError
                    ? Text(
                        "Recuerda que tienes 3 intentos",
                        textAlign: TextAlign.center,
                        style: gilroyBold.copyWith(
                            fontSize: 14,
                            color: colorNegro,
                            letterSpacing: -0.13),
                      )
                    : Text(
                        "Recuerda qué después de los 3 intentos ",
                        textAlign: TextAlign.center,
                        style: gilroyRegular.copyWith(
                            fontSize: 14,
                            color: colorNegro,
                            letterSpacing: -0.13),
                      ),
                !isError
                    ? Text(
                        "al agotarlos podrás volverlo a intentar el ${getNextDate()} a las 00hrs",
                        textAlign: TextAlign.center,
                        style: gilroyRegular.copyWith(
                            fontSize: 14,
                            color: colorNegro,
                            letterSpacing: -0.13),
                      )
                    : Text(
                        "se bloqueara el acceso hasta el ${getNextDate()} a las 00hrs",
                        textAlign: TextAlign.center,
                        style: gilroyBold.copyWith(
                            fontSize: 14,
                            color: colorNegro,
                            letterSpacing: -0.13),
                      ),
                const SizedBox(
                  height: 20,
                ),
                ButtonPrimary(
                  textButton: "Continuar",
                  onpressParam: () {
                    // context.pop("llego al otp y correcot");
                    //Error otp
                    setState(() {
                      isError = true;
                    });
                    return;

                    // Caduco Otp
                    fadeInRigthTransition(
                        context,
                        ErrorOtpPopUp(
                          textButtom: "Reenviar código",
                          padding: const EdgeInsets.fromLTRB(22, 40, 22, 23),
                          onpressParam: () {
                            context.pop();
                          },
                          widgets: [
                            const SizedBox(height: 23),
                            Text(
                              "Tu código OTP ha caducado.",
                              textAlign: TextAlign.center,
                              style: gilroyRegular.copyWith(fontSize: 16),
                            ),
                            Text(
                              "Por favor, solicita uno nuevamente.",
                              textAlign: TextAlign.center,
                              style: gilroyRegular.copyWith(fontSize: 16),
                            ),
                          ],
                        ));
                    // agoto intentos
                    // fadeInRigthTransition(
                    //     context,
                    //     ErrorOtpPopUp(
                    //       textButtom: "Volver",
                    //       padding: const EdgeInsets.fromLTRB(22, 20, 22, 23),
                    //       onpressParam: () {
                    //         context.pop();
                    //       },
                    //       widgets: [
                    //         const SizedBox(height: 16),
                    //         Text(
                    //           "Has agotado todos tus intentos diarios para solicitar una OTP.",
                    //           textAlign: TextAlign.center,
                    //           style: gilroyRegular.copyWith(fontSize: 16),
                    //         ),
                    //         const SizedBox(height: 18),
                    //         Text(
                    //           "Podrás volverlo a intentar el",
                    //           textAlign: TextAlign.center,
                    //           style: gilroyRegular.copyWith(fontSize: 16),
                    //         ),
                    //         Text(
                    //           "${getNextDate()} a las 00hrs",
                    //           textAlign: TextAlign.center,
                    //           style: gilroyBold.copyWith(
                    //               fontSize: 16, color: colorNegro),
                    //         )
                    //       ],
                    //     ));
                    /*
                   
                    context.pop();
                    */

                    //pop up usuario creado
                    // UserCreatedPopUp
                    //pop up usuario ya existe
                    // fadeInRigthTransition(context, const UserRegistered());
                  },
                ),
                const SizedBox(
                  height: 12,
                ),
                InkWell(
                  onTap: () {
                    _pinEditingController.clear();
                    fadeInRigthTransition(
                        context, const SendedOtp(intentos: 3));
                  },
                  child: Text(
                    "Reenviar código",
                    style: gilroyBold16.copyWith(
                        color: Colors.transparent,
                        fontSize: 16,
                        shadows: [
                          const Shadow(offset: Offset(0, -2), color: colorAzul)
                        ], // Step 3 SEE HERE
                        decoration: TextDecoration.underline,
                        decorationStyle: TextDecorationStyle.solid,
                        decorationColor: colorAzul,
                        decorationThickness: 1),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class UserCreatedPopUp extends StatelessWidget {
  const UserCreatedPopUp({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 360),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 40, 22, 20),
            child: Column(
              children: [
                SvgPicture.asset(
                  "assets/icons/ok_alerta.svg",
                  width: 114,
                ),
                const SizedBox(height: 48),
                Text(
                  "Se ha creado tu usuario correctamente",
                  style: gilroyRegular.copyWith(fontSize: 16),
                ),
                const Expanded(child: SizedBox()),
                ButtonPrimary(
                    textButton: "Iniciar sesión",
                    onpressParam: () => context.pushReplacement('/login'))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class UserRegistered extends StatelessWidget {
  const UserRegistered({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 366),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 19, 22, 20),
            child: Column(
              children: [
                SvgPicture.asset(
                  "assets/icons/alerta.svg",
                  width: 114,
                  height: 114,
                ),
                const SizedBox(height: 15),
                Text(
                  "El usuario ya se encuentra registrado en nuestro sistema. Por favor inicia sesión para continuar.",
                  textAlign: TextAlign.center,
                  style: gilroyRegular.copyWith(fontSize: 16),
                ),
                const SizedBox(height: 15),
                Text(
                  "Si olvidaste tu información para ingresar presiona",
                  textAlign: TextAlign.center,
                  style: gilroyRegular.copyWith(fontSize: 16),
                ),
                const SizedBox(height: 5),
                InkWell(
                  onTap: () async {},
                  child: Text(
                    "Olvidé mi contraseña",
                    style: gilroyBold16.copyWith(
                        color: Colors.transparent,
                        fontSize: 16,
                        shadows: [
                          const Shadow(offset: Offset(0, -2), color: colorAzul)
                        ], // Step 3 SEE HERE
                        decoration: TextDecoration.underline,
                        decorationStyle: TextDecorationStyle.solid,
                        decorationColor: colorAzul,
                        decorationThickness: 1),
                  ),
                ),
                const Expanded(child: SizedBox()),
                ButtonPrimary(
                    textButton: "Iniciar sesión",
                    onpressParam: () => context.pushReplacement('/login'))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SendedOtp extends StatelessWidget {
  final int intentos;
  const SendedOtp({super.key, required this.intentos});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 360),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 40, 22, 20),
            child: Column(
              children: [
                SvgPicture.asset(
                  "assets/icons/ok_alerta.svg",
                  width: 114,
                ),
                const SizedBox(height: 48),
                Text(
                  "Hemos reenviado el código a tu correo. (Te quedan $intentos intentos)",
                  textAlign: TextAlign.center,
                  style: gilroyRegular.copyWith(fontSize: 16),
                ),
                const Expanded(child: SizedBox()),
                ButtonPrimary(
                    textButton: "Continuar",
                    onpressParam: () {
                      context.pop();
                    })
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ErrorOtpPopUp extends StatelessWidget {
  final List<Widget> widgets;
  final void Function()? onpressParam;
  final String textButtom;
  final EdgeInsetsGeometry padding;
  const ErrorOtpPopUp(
      {super.key,
      required this.widgets,
      this.onpressParam,
      required this.textButtom,
      required this.padding});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 360),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: padding,
            child: Column(
              children: [
                SvgPicture.asset(
                  "assets/icons/error_alerta.svg",
                  width: 114,
                ),
                ...widgets,
                const Expanded(child: SizedBox()),
                ButtonPrimary(
                    textButton: textButtom, onpressParam: onpressParam)
              ],
            ),
          ),
        ),
      ),
    );
  }
}

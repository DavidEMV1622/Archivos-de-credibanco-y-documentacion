import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class FullModalScreen extends StatefulWidget {
  final String titulo;
  final String content;
  const FullModalScreen(
      {super.key, required this.titulo, required this.content});

  @override
  State<FullModalScreen> createState() => _FullModalScreenState();
}

class _FullModalScreenState extends State<FullModalScreen> {
  ScrollController scrollController = ScrollController();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (scrollController.position.maxScrollExtent == 0) {
        if (mounted) {
          setState(() {
            isAtEnd = true;
          });
        }
      }
    });
    scrollController.addListener(() {
      if ((scrollController.position.pixels + 500) >=
          scrollController.position.maxScrollExtent) {
        isAtEnd = true;
        setState(() {});
      }
    });
    super.initState();
  }

  bool isAtEnd = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        surfaceTintColor: Colors.transparent,
        leading: CustomBackButtom(onPressed: () => context.pop(false)),
      ),
      body: SingleChildScrollView(
        controller: scrollController,
        child: Padding(
          padding: const EdgeInsets.only(left: 24, right: 24, bottom: 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.titulo,
                style: gilroyBold24.copyWith(fontSize: 20),
              ),
              const SizedBox(height: 15),
              Text(widget.content),
            ],
          ),
        ),
      ),
      persistentFooterButtons: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: ButtonPrimary(
            textButton: "Aceptar",
            isActive: isAtEnd,
            onpressParam: isAtEnd == true
                ? () {
                    context.pop(true);
                  }
                : null,
          ),
        )
      ],
    );
  }
}

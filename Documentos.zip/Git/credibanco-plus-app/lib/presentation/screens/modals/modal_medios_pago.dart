import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

void showMediosPagoModal(BuildContext context, String valor) {
  showGeneralDialog(
    context: context,
    barrierLabel: "Barrier",
    barrierDismissible: true,
    barrierColor: const Color.fromRGBO(0, 175, 170, 0.8),
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (_, __, ___) {
      return Center(
        child: Container(
          constraints: const BoxConstraints(maxHeight: 390),
          margin: const EdgeInsets.symmetric(horizontal: 20),
          child: Card(
            color: const Color(0XFFF5F8F7),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Positioned(
                          right: 13,
                          top: 13,
                          child: IconButton(
                              onPressed: () => context.pop(),
                              icon: SvgPicture.asset(
                                  "assets/icons/close_icon.svg"))),
                      Positioned(
                        top: 25,
                        left: 25,
                        child: Text(
                          "\$ $valor",
                          style: gilroyBold.copyWith(
                              fontSize: 32, color: const Color(0XFF252525)),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 17),
                      Text("Selecciona el medio de pago",
                          style: gilroyBold16.copyWith(
                              fontSize: 14, color: colorVerde),
                          textAlign: TextAlign.center),
                      const SizedBox(height: 41),
                      _CardMedioPago(
                        titulo: "Nequi",
                        icon: SvgPicture.asset(
                            "assets/icons/medios_pago/nequi_icon.svg",
                            height: 30),
                        onpress: () {
                          context.push('/login');
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      _CardMedioPago(
                        titulo: "Daviplata",
                        icon: SvgPicture.asset(
                            "assets/icons/medios_pago/daviplata_icon.svg",
                            height: 30),
                        onpress: () {
                          context.push('/login');
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      _CardMedioPago(
                        titulo: "Código QR",
                        icon: SvgPicture.asset(
                            "assets/icons/medios_pago/qr_icon.svg",
                            height: 30),
                        onpress: () {
                          context.push('/login');
                        },
                      ),
                      const SizedBox(
                        height: 16,
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionBuilder: (_, anim, __, child) {
      Tween<Offset> tween;
      if (anim.status == AnimationStatus.reverse) {
        tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
      } else {
        tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
      }

      return SlideTransition(
        position: anim.drive(
          tween.chain(CurveTween(curve: Curves.easeIn)),
        ),
        child: child,
      );
    },
  );
}

class _CardMedioPago extends StatelessWidget {
  final String titulo;
  final Widget icon;
  final void Function()? onpress;
  const _CardMedioPago(
      {required this.titulo, required this.icon, required this.onpress});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onpress,
      child: Container(
        height: 70,
        padding: const EdgeInsets.symmetric(horizontal: 23),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.15),
                  offset: Offset(0, 2),
                  blurRadius: 2,
                  spreadRadius: 0)
            ]),
        width: double.infinity,
        child: Row(
          children: [
            icon,
            const SizedBox(width: 10),
            Text(
              titulo,
              style: gilroyRegular.copyWith(color: colorVerde),
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }
}

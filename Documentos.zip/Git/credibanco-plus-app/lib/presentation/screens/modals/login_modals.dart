import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/presentation/widgets/buttons.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';

class ActivarHuellaPopUp extends StatelessWidget {
  const ActivarHuellaPopUp({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        constraints: const BoxConstraints(maxHeight: 328),
        child: Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 22),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const SizedBox(height: 26),
                SvgPicture.asset(
                  "assets/icons/fingerprint.svg",
                  height: 120,
                ),
                const SizedBox(height: 16),
                Text(
                    "Hemos detectado que tu dispositivo tiene un lector de huella",
                    style: gilroyRegular.copyWith(fontSize: 14),
                    textAlign: TextAlign.center),
                const SizedBox(height: 18),
                Text("¿Quieres registrar tu huella para ingresar?",
                    style: gilroyBold.copyWith(fontSize: 14, color: colorVerde),
                    textAlign: TextAlign.center),
                const Expanded(child: SizedBox()),
                Row(
                  children: [
                    Flexible(
                      child: ButtonSecondary(
                          textButton: "No",
                          onpressParam: () {
                            context.pop(false);
                          }),
                    ),
                    const SizedBox(width: 15),
                    Flexible(
                      child: ButtonPrimary(
                        textButton: "Si",
                        onpressParam: () async {
                          context.pop(true);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:async';

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';

class HomeBottomNavigationbar extends StatelessWidget {
  const HomeBottomNavigationbar({super.key});

  @override
  Widget build(BuildContext context) {
    final bottonCtrl = Get.put(NavigationBottomController());
    return Obx(
      () => BottomNavigationBar(
        backgroundColor: const Color(0xFFF5F8F7),
        selectedItemColor: colorNegro,
        selectedFontSize: 0,
        currentIndex: bottonCtrl.currentIndex.value!,
        items: const [
          BottomNavigationBarItem(
              icon: _ItemBottomNavigation(
                asset: "assets/icons/datafono_bottom.svg",
                label: "Recibir pagos",
                index: 0,
              ),
              label: ""),
          BottomNavigationBarItem(
              icon: _ItemBottomNavigation(
                asset: "assets/icons/movimientos_bottom.svg",
                label: "Movimientos",
                index: 1,
              ),
              label: ""),
          BottomNavigationBarItem(
              icon: _ItemBottomNavigation(
                asset: "assets/icons/mas_bottom.svg",
                label: "Más",
                index: 2,
              ),
              label: ""),
        ],
      ),
    );
  }
}

class _ItemBottomNavigation extends StatelessWidget {
  final String asset;
  final String label;
  final int index;

  const _ItemBottomNavigation({
    required this.asset,
    required this.label,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    final bottonCtrl = Get.find<NavigationBottomController>();
    return SizedBox(
      width: double.infinity,
      height: 60,
      child: Obx(
        () => TweenAnimationBuilder(
            curve: Curves.easeOut,
            duration: const Duration(milliseconds: 300),
            tween: ColorTween(
                end: bottonCtrl.currentIndex.value! == index
                    ? colorNegro
                    : const Color(0xFFF5F8F7),
                begin: bottonCtrl.currentIndex.value! == index
                    ? const Color(0xFFF5F8F7)
                    : colorNegro),
            builder: (BuildContext context, Color? value, Widget? child) {
              return Material(
                color: bottonCtrl.currentIndex.value! == index
                    ? value
                    : const Color(0xFFF5F8F7),
                child: InkWell(
                  splashColor: Colors.transparent,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        asset,
                        color: bottonCtrl.currentIndex.value! == index
                            ? Colors.white
                            : null,
                      ),
                      Text(label,
                          style: gilroyRegular.copyWith(
                              color: bottonCtrl.currentIndex.value! == index
                                  ? Colors.white
                                  : null)),
                    ],
                  ),
                  onTap: () {
                    bottonCtrl.currentIndex.value = index;
                    // if (index == 2) {
                    //   bottonCtrl.keyScaffold.value!.currentState!.openDrawer();
                    // }
                    if (index == 1 || index == 2) {
                      context.pushReplacement('/login');
                      Timer(const Duration(milliseconds: 500), () {
                        bottonCtrl.currentIndex.value = 0;
                      });
                    }
                  },
                ),
              );
            }),
      ),
    );
  }
}

class NavigationBottomController extends GetxController {
  final currentIndex = Rxn<int>(0);
  final keyScaffold = Rxn<GlobalKey<ScaffoldState>>(GlobalKey<ScaffoldState>());
}

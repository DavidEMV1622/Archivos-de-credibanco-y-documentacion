import 'dart:io';
import 'package:flutter/material.dart';

class CustomBackButtom extends StatelessWidget {
  final void Function()? onPressed;
  const CustomBackButtom({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(left: 15),
      child: IconButton(
        icon: Platform.isAndroid
            ? const Icon(Icons.arrow_back)
            : const Icon(Icons.arrow_back_ios),
        onPressed: onPressed,
      ),
    );
  }
}

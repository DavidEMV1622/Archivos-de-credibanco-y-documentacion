import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:credibanco_plus_app/helpers/number_formats.dart';
import 'package:credibanco_plus_app/presentation/screens/home_publico/controllers/calc_controller.dart';
import 'package:credibanco_plus_app/presentation/screens/modals/modals.dart';
import 'package:credibanco_plus_app/presentation/widgets/buttons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Calculadora extends StatelessWidget {
  const Calculadora({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    var colorNegro2 = colorNegro.withOpacity(0.1);
    final calcController = Get.find<CalcController>();
    return Container(
      margin: EdgeInsets.symmetric(horizontal: size.width * 0.08),
      width: double.infinity,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _ButtonCalc(
                text: "1",
                onPressed: () => calcController.addNumber("1"),
                border: Border(
                    right: BorderSide(color: colorNegro2),
                    bottom: BorderSide(color: colorNegro2)),
              ),
              _ButtonCalc(
                  text: "2",
                  onPressed: () => calcController.addNumber("2"),
                  border: Border(
                      right: BorderSide(color: colorNegro2),
                      bottom: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "3",
                  onPressed: () => calcController.addNumber("3"),
                  border: Border(bottom: BorderSide(color: colorNegro2))),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _ButtonCalc(
                  text: "4",
                  onPressed: () => calcController.addNumber("4"),
                  border: Border(
                      right: BorderSide(color: colorNegro2),
                      bottom: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "5",
                  onPressed: () => calcController.addNumber("5"),
                  border: Border(
                      right: BorderSide(color: colorNegro2),
                      bottom: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "6",
                  onPressed: () => calcController.addNumber("6"),
                  border: Border(bottom: BorderSide(color: colorNegro2))),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _ButtonCalc(
                  text: "7",
                  onPressed: () => calcController.addNumber("7"),
                  border: Border(
                      right: BorderSide(color: colorNegro2),
                      bottom: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "8",
                  onPressed: () => calcController.addNumber("8"),
                  border: Border(
                      right: BorderSide(color: colorNegro2),
                      bottom: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "9",
                  onPressed: () => calcController.addNumber("9"),
                  border: Border(bottom: BorderSide(color: colorNegro2))),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _ButtonCalc(
                  text: "C",
                  onPressed: () => calcController.funAc(),
                  border: Border(right: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                  text: "0",
                  onPressed: () => calcController.addNumber("0"),
                  border: Border(right: BorderSide(color: colorNegro2))),
              _ButtonCalc(
                text: "+",
                onPressed: () => calcController.addSum(),
              ),
            ],
          ),
          const SizedBox(
            height: 15,
          ),
          Obx(() => calcController.inputValorCtrl.value != null
              ? ButtonPrimary(
                  isActive: calcController.inputValorCtrl.value!.text != "\$ 0",
                  onpressParam: () async {
                    showMediosPagoModal(
                        context,
                        !calcController.isSum.value!
                            ? NumberFormats.currencyFormat(
                                calcController.inputValorCtrl.value!.text)
                            : NumberFormats.currencyFormat(
                                calcController.totalSum.value!));
                  },
                  textButton:
                      "Cobrar \$ ${calcController.isSum.value! ? NumberFormats.currencyFormat(calcController.totalSum.value!) : NumberFormats.currencyFormat(calcController.inputValorCtrl.value!.text)}")
              : const SizedBox())
        ],
      ),
    );
  }
}

class _ButtonCalc extends StatelessWidget {
  final String text;
  final Function onPressed;
  final BoxBorder? border;
  const _ButtonCalc({required this.text, required this.onPressed, this.border});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return InkWell(
      onTap: () => onPressed(),
      splashColor: colorAzul.withOpacity(0.2),
      highlightColor: colorAzul.withOpacity(0.2),
      child: Container(
        decoration: BoxDecoration(border: border),
        height: 55,
        width: (size.width - (size.width * 0.16)) / 3,
        child: Center(
          child: Text(
            text,
            style: gilroyBold24.copyWith(color: const Color(0XFF252525)),
          ),
        ),
      ),
    );
  }
}

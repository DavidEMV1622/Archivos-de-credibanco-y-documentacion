import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AuthBio extends StatelessWidget {
  final void Function()? onPressed;
  final String titulo;
  final bool isError;
  final String msgError;
  const AuthBio(
      {super.key,
      required this.titulo,
      this.onPressed,
      required this.isError,
      required this.msgError});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 16),
        Text(titulo,
            style: isError
                ? gilroyRegular.copyWith(fontSize: 10, color: colorRojo)
                : gilroyRegular.copyWith(fontSize: 10, color: colorVerde)),
        IconButton(
            onPressed: onPressed,
            icon: SvgPicture.asset(
              "assets/icons/fingerprint.svg",
              color: isError ? colorRojo : null,
            )),
        if (isError && msgError != "")
          Text(msgError,
              style: gilroyRegular.copyWith(fontSize: 10, color: colorRojo)),
        const SizedBox(height: 35),
      ],
    );
  }
}

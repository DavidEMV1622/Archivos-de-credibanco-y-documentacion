import 'package:flutter/material.dart';

import 'package:credibanco_plus_app/config/styles/styles.dart';

class ButtonPrimary extends StatelessWidget {
  final void Function()? onpressParam;
  final String textButton;
  final bool isActive;
  const ButtonPrimary(
      {super.key,
      this.onpressParam,
      required this.textButton,
      this.isActive = true});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
          onPressed: isActive ? onpressParam : null,
          style: ButtonStyle(
              padding: const MaterialStatePropertyAll(
                  EdgeInsets.symmetric(horizontal: 20, vertical: 10)),
              foregroundColor:
                  const MaterialStatePropertyAll(colorAmarillosecond),
              elevation: const MaterialStatePropertyAll(0),
              minimumSize: const MaterialStatePropertyAll(Size(140, 40)),
              textStyle: const MaterialStatePropertyAll(gilroyBold16),
              backgroundColor: MaterialStateProperty.resolveWith((states) {
                if (states.contains(MaterialState.disabled)) {
                  return colorAmarilloInactivo;
                }
                return colorAmarillo;
              }),
              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)))),
          child: Text(textButton,
              style: gilroyBold16.copyWith(color: Colors.black))),
    );
  }
}

class ButtonSecondary extends StatelessWidget {
  final void Function()? onpressParam;
  final String textButton;
  const ButtonSecondary(
      {super.key, this.onpressParam, required this.textButton});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
          onPressed: onpressParam,
          style: ElevatedButton.styleFrom(
              shadowColor: Colors.transparent,
              side: const BorderSide(color: Color(0xFF000000), width: 1),
              elevation: 0,
              minimumSize: const Size(140, 40),
              textStyle: gilroyBold16,
              backgroundColor: const Color(0xFFFFFFFF),
              disabledBackgroundColor: const Color(0xFFF5F8F7),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8))),
          child: Text(textButton, style: gilroyBold16)),
    );
  }
}

import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';

class CheckBoxTile extends StatelessWidget {
  final String title;
  final bool value;
  final void Function(bool?)? onChanged;
  const CheckBoxTile({
    super.key,
    required this.title,
    required this.value,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 15,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(
            width: 16,
            child: Checkbox(
              shape: const CircleBorder(
                side: BorderSide(color: Colors.grey),
              ),
              checkColor: Colors.white,
              value: value,
              tristate: false,
              onChanged: (bool? value) {},
            ),
          ),
          const SizedBox(width: 12.45),
          Text(
            title,
            style: gilroyRegular.copyWith(color: colorNegro, fontSize: 12),
          )
        ],
      ),
    );
  }
}

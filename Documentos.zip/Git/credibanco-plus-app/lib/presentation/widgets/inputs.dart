import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CustomInput extends StatelessWidget {
  final String placeholder;
  final TextEditingController textController;
  final TextInputType textInputType;
  final bool isPassword;
  final bool isOk;
  final bool isError;
  final String? Function(String?)? validator;
  final String? Function(String?)? onchage;
  final Function()? onTap;
  final Function(PointerDownEvent)? onTapOutside;
  final EdgeInsets? contentPadding;
  final List<TextInputFormatter>? inputFormatters;
  final Widget? suffixIcon;

  const CustomInput(
      {super.key,
      required this.placeholder,
      required this.textController,
      this.textInputType = TextInputType.text,
      this.isPassword = false,
      this.isOk = false,
      this.isError = false,
      this.contentPadding = const EdgeInsets.only(top: 8, left: 15),
      this.validator,
      this.onchage,
      this.onTap,
      this.onTapOutside,
      this.inputFormatters,
      this.suffixIcon});

  @override
  Widget build(BuildContext context) {
    final inputTheme = Theme.of(context).inputDecorationTheme;

    return TextFormField(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        autocorrect: false,
        showCursor: true,
        controller: textController,
        keyboardType: textInputType,
        obscureText: isPassword,
        textAlignVertical: TextAlignVertical.center,
        validator: validator,
        onChanged: onchage,
        onTap: onTap,
        onTapOutside: (p0) {
          final FocusScopeNode focus = FocusScope.of(context);
          if (!focus.hasPrimaryFocus && focus.hasFocus) {
            FocusManager.instance.primaryFocus!.unfocus();
          }
        },
        inputFormatters: inputFormatters,
        style: gilroyRegular.copyWith(
            fontSize: isPassword ? 20 : 14, color: Colors.black),
        decoration: InputDecoration(
          enabledBorder: isError
              ? inputTheme.errorBorder
              : !isOk
                  ? inputTheme.enabledBorder
                  : inputTheme.enabledBorder!.copyWith(
                      borderSide: const BorderSide(color: colorAzul, width: 2)),
          focusedBorder: !isOk
              ? inputTheme.enabledBorder
              : inputTheme.enabledBorder!.copyWith(
                  borderSide: const BorderSide(color: colorAzul, width: 2)),
          filled: true,
          fillColor: Colors.white,
          hintText: placeholder,
          suffixIcon: suffixIcon,
          errorStyle: const TextStyle(height: 0),
          contentPadding: contentPadding,
          hintStyle: const TextStyle(
              color: Color(0XFFA7A9AC),
              fontFamily: 'Gilroy-Regular',
              fontSize: 14),
        ));
  }
}

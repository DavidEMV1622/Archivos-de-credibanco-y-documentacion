import 'package:credibanco_plus_app/terms/domain/entities/terminos.dart';

abstract class TermsDatasource {
  Future<Termns> getTerms(String idTerms);

  Future<bool> acceptTerms(String idTerms, String user);
}

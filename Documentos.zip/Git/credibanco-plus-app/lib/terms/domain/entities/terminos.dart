class Termns {
  final String content;
  final String titulo;
  final String id;

  Termns({required this.content, required this.titulo, required this.id});
}

import 'package:credibanco_plus_app/terms/domain/entities/terminos.dart';
import 'package:credibanco_plus_app/terms/infraestructure/models/portal_mf_terms_response.dart';

class TermsMapper {
  static Termns portalMfTermsToTerms(PortalMfTermsResponse res) => Termns(
      content: res.content.content,
      titulo: res.content.description,
      id: res.content.name);
}

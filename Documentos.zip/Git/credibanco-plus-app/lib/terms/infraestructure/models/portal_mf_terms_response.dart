import 'dart:convert';

PortalMfTermsResponse portalMfTermsResponseFromJson(String str) =>
    PortalMfTermsResponse.fromJson(json.decode(str));

String portalMfTermsResponseToJson(PortalMfTermsResponse data) =>
    json.encode(data.toJson());

class PortalMfTermsResponse {
  final String message;
  final DateTime date;
  final Content content;

  PortalMfTermsResponse({
    required this.message,
    required this.date,
    required this.content,
  });

  factory PortalMfTermsResponse.fromJson(Map<String, dynamic> json) =>
      PortalMfTermsResponse(
        message: json["message"],
        date: DateTime.parse(json["date"]),
        content: Content.fromJson(json["content"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "date":
            "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}",
        "content": content.toJson(),
      };
}

class Content {
  final String name;
  final String description;
  final String dateInvalid;
  final String content;

  Content({
    required this.name,
    required this.description,
    required this.dateInvalid,
    required this.content,
  });

  factory Content.fromJson(Map<String, dynamic> json) => Content(
        name: json["name"],
        description: json["description"],
        dateInvalid: json["dateInvalid"],
        content: latin1.decode(base64.decode(json["content"])),
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "description": description,
        "dateInvalid": dateInvalid,
        "content": content,
      };
}

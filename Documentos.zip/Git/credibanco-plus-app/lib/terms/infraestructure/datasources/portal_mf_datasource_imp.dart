import 'package:credibanco_plus_app/config/constants/environment.dart';
import 'package:credibanco_plus_app/terms/domain/datasources/terms_datasource.dart';
import 'package:credibanco_plus_app/terms/domain/entities/terminos.dart';
import 'package:credibanco_plus_app/terms/infraestructure/mappers/terms_mapper.dart';
import 'package:credibanco_plus_app/terms/infraestructure/models/portal_mf_terms_response.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PortalMfDatasource extends TermsDatasource {
  final storage = const FlutterSecureStorage();

  final dio = Dio(BaseOptions(
    baseUrl:
        "https://portal-mf-api-portal.${Environment.baseUrl}/portal/legal/",
  ));

  @override
  Future<bool> acceptTerms(String idTerms, String user) async {
    final token = await storage.read(key: "tokenAnonymus");

    try {
      final res = await dio.post("accept/$idTerms/$user",
          options: Options(headers: {'Authorization': 'Bearer $token'}));
      return res.statusCode == 200 ? true : false;
    } on DioException catch (e) {
      return false;
    }
  }

  @override
  Future<Termns> getTerms(String idTerms) async {
    final token = await storage.read(key: "tokenAnonymus");

    final res = await dio.get("term/content/$idTerms",
        options: Options(headers: {'Authorization': 'Bearer $token'}));

    return TermsMapper.portalMfTermsToTerms(
        PortalMfTermsResponse.fromJson(res.data));
  }
}

import 'package:credibanco_plus_app/terms/domain/datasources/terms_datasource.dart';
import 'package:credibanco_plus_app/terms/domain/entities/terminos.dart';
import 'package:credibanco_plus_app/terms/domain/respositories/terms_repositoriy.dart';

class TermsRepositoryImple extends TermsRepository {
  final TermsDatasource termsDatasource;

  TermsRepositoryImple(this.termsDatasource);

  @override
  Future<bool> acceptTerms(String idTerms, String user) {
    return termsDatasource.acceptTerms(idTerms, user);
  }

  @override
  Future<Termns> getTerms(String idTerms) {
    return termsDatasource.getTerms(idTerms);
  }
}

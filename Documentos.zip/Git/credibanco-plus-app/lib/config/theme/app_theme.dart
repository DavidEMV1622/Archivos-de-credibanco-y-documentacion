import 'package:credibanco_plus_app/config/styles/styles.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';

class AppTheme {
  ThemeData getTheme() => ThemeData().copyWith(
      appBarTheme: const AppBarTheme().copyWith(
        iconTheme: const IconThemeData(
          color: colorVerde,
        ),
      ),
      cardTheme: const CardTheme(color: Colors.white),
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: CustomTransitionBuilder(),
      }),
      dividerColor: Colors.transparent,
      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateProperty.resolveWith<Color>((states) {
          if (states.contains(MaterialState.selected)) {
            return colorAzul;
          }
          return Colors.grey;
        }),
      ),
      scaffoldBackgroundColor: const Color(0xFFFFFFFF),
      useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme().copyWith(
        enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(
              width: 1,
              color: Color(0xFFCFCCD3),
            )),
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(
              width: 1,
              color: Color(0xFFCFCCD3),
            )),
        focusedErrorBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(
              width: 2,
              color: colorRojo,
            )),
        errorBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(
              width: 2,
              color: colorRojo,
            )),
      ));

  PinTheme getDefaultPinTheme() => PinTheme(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(color: const Color(0XFFCFCCD3))),
        width: 35,
        height: 44,
        textStyle: gilroyMedium.copyWith(fontSize: 24),
      );

  PinTheme getSubmittPinTheme() => PinTheme(
      width: 35,
      height: 44,
      textStyle: gilroyMedium.copyWith(fontSize: 24),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.0),
          border: Border.all(
            color: colorAzul, // Color del borde cuando el campo está lleno
            width: 2.0,
          )));

  PinTheme getErrorPinTheme() => PinTheme(
      width: 35,
      height: 44,
      textStyle: gilroyMedium.copyWith(fontSize: 24),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.0),
          border: Border.all(
            color: colorRojo, // Color del borde cuando el campo está lleno
            width: 2.0,
          )));
}

class CustomTransitionBuilder extends PageTransitionsBuilder {
  const CustomTransitionBuilder();
  @override
  Widget buildTransitions<T>(
      PageRoute<T> route,
      BuildContext context,
      Animation<double> animation,
      Animation<double> secondaryAnimation,
      Widget child) {
    final tween =
        Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.ease));
    return ScaleTransition(scale: animation.drive(tween), child: child);
  }
}

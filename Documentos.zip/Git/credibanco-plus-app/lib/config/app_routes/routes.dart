import 'package:credibanco_plus_app/presentation/screens/home_publico/home_screen.dart';
import 'package:credibanco_plus_app/presentation/screens/home_publico/login_screen.dart';
import 'package:credibanco_plus_app/presentation/screens/home_publico/password_screen.dart';
import 'package:credibanco_plus_app/presentation/screens/home_publico/registrate_screen.dart';
import 'package:credibanco_plus_app/presentation/screens/splash/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(
      path: '/splash',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/home',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/home_user',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/login',
      pageBuilder: (context, state) {
        return CustomTransitionPage(
          child: const LoginScreen(),
          transitionsBuilder: (BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child) {
            return FadeTransition(
                opacity: CurveTween(curve: Curves.easeIn).animate(animation),
                child: child);
          },
        );
      },
    ),
    GoRoute(
      path: '/registrate',
      builder: (context, state) => const RegistrateScreen(),
    ),
    GoRoute(
      path: '/password/:email',
      builder: (context, state) =>
          PasswordScreen(email: state.pathParameters['email'] ?? ''),
    ),
  ],
);

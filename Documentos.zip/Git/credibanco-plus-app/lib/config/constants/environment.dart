import 'package:flutter_dotenv/flutter_dotenv.dart';

class Environment {
  static String usernameAnonymous = dotenv.env['username_anonymous'] ?? "";
  static String passwordAnonymous = dotenv.env['password_anonymous'] ?? "";
  static String clientIdAnonymous = dotenv.env['client_id_anonymous'] ?? "";
  static String grantTypeAnonymous = dotenv.env['grant_type_anonymous'] ?? "";
  static String grantTypeRefreshAnonymous =
      dotenv.env['grant_type_refresh_anonymous'] ?? "";
  static String clientSecretAnonymous =
      dotenv.env['client_secret_anonymous'] ?? "";
  static String refreshTokenAnonymous =
      dotenv.env['refresh_token_anonymous'] ?? "";
  static String baseUrl = dotenv.env['baseUrl'] ?? "";
}

part of './styles.dart';

const TextStyle gilroyBold = TextStyle(
    fontSize: 21,
    color: colorVerde,
    fontFamily: 'Gilroy-Bold',
    letterSpacing: -0.16875);

const TextStyle gilroyBold24 = TextStyle(
    fontSize: 24,
    color: colorVerde,
    fontFamily: 'Gilroy-Bold',
    letterSpacing: -0.16875);

const TextStyle gilroyBold16 = TextStyle(
  fontSize: 16,
  color: Color(0XFF000000),
  fontFamily: 'Gilroy-Bold',
  letterSpacing: -0.16875,
);

const TextStyle gilroyRegular = TextStyle(
  fontSize: 14,
  color: colorNegro,
  fontFamily: 'Gilroy-Regular',
  letterSpacing: -0.16875,
);

const TextStyle gilroyMedium = TextStyle(
  fontSize: 14,
  color: colorNegro,
  fontFamily: 'Gilroy-Medium',
  letterSpacing: -0.16875,
);

const TextStyle gilroyLight = TextStyle(
  fontSize: 12,
  color: colorNegro,
  fontFamily: 'Gilroy-Light',
  letterSpacing: -0.16875,
);

part of './styles.dart';

const Color colorVerde = Color(0xFF124734);
const Color colorAzul = Color(0xFF00AFAA);
const Color colorNegro = Color(0xFF4D4851);
const Color colorRojo = Color(0xFFFF0F00);

const Color colorAmarillo = Color(0xFFFFB600);
const Color colorAmarillosecond = Color(0xFFE2A200);
const Color colorAmarilloInactivo = Color(0XFFD9D9D9);

import 'package:credibanco_plus_app/config/constants/environment.dart';
import 'package:credibanco_plus_app/createuser/domain/datasources/createuser_datasource.dart';
import 'package:credibanco_plus_app/createuser/domain/entities/createuser_request.dart';
import 'package:dio/dio.dart';

class PortalMfApiImple extends CreateUserDatasource {
  final dio = Dio(BaseOptions(
      baseUrl: 'https://portal-mf-api-portal.${Environment.baseUrl}/'));

  @override
  Future<bool> createUser(CreateUserRequest request) async {
    final respose = await dio.post("portal/user/create/otp", data: {});
    return respose.statusCode == 200;
  }
}

import 'package:credibanco_plus_app/createuser/domain/datasources/createuser_datasource.dart';
import 'package:credibanco_plus_app/createuser/domain/entities/createuser_request.dart';
import 'package:credibanco_plus_app/createuser/domain/repositories/createuser_repository.dart';

class CreateUserRepositoryImple extends CreateUserRepository {
  final CreateUserDatasource datasource;

  CreateUserRepositoryImple(this.datasource);

  @override
  Future<bool> createUser(CreateUserRequest request) {
    return datasource.createUser(request);
  }
}

class CreateUserRequest {
  final String nit;
  final String profile;
  final Attributes attributes;
  final bool enabled;
  final List<Credential> credentials;

  CreateUserRequest({
    required this.nit,
    required this.profile,
    required this.attributes,
    required this.enabled,
    required this.credentials,
  });
}

class Attributes {
  final List<String> group;
  final List<String> document;
  final List<String> phone;

  Attributes({
    required this.group,
    required this.document,
    required this.phone,
  });
}

class Credential {
  final String type;
  final String value;

  Credential({
    required this.type,
    required this.value,
  });
}

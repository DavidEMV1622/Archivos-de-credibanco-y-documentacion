import 'package:credibanco_plus_app/createuser/domain/entities/createuser_request.dart';

abstract class CreateUserRepository {
  Future<bool> createUser(CreateUserRequest request);
}

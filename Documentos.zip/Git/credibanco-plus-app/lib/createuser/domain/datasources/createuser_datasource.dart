import 'package:credibanco_plus_app/createuser/domain/entities/createuser_request.dart';

abstract class CreateUserDatasource {
  Future<bool> createUser(CreateUserRequest request);
}

class Token {
  final String accessToken;
  final String refreshToken;
  final dynamic lastLoginDate;

  Token({
    required this.accessToken,
    required this.refreshToken,
    this.lastLoginDate,
  });
}

import '../entities/token.dart';

abstract class TokenRepository {
  Future<Token?> getToken({required String user, required String password});
  Future<Token?> refreshToken({required String refreshToken});
}

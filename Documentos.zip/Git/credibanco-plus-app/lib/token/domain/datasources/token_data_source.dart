import '../entities/token.dart';

abstract class TokenDataSource {
  Future<Token?> getToken({required String user, required String password});
  Future<Token?> refreshToken({required String refreshToken});
}

import 'package:credibanco_plus_app/config/constants/environment.dart';
import 'package:credibanco_plus_app/token/domain/datasources/token_data_source.dart';
import 'package:credibanco_plus_app/token/domain/entities/token.dart';
import 'package:credibanco_plus_app/token/infraestructure/mappers/restoken_mapper.dart';
import 'package:credibanco_plus_app/token/infraestructure/models/portalmf_api.dart';
import 'package:dio/dio.dart';

class PortalmfapiDatasourceImp extends TokenDataSource {
  final dio = Dio(BaseOptions(
      baseUrl: 'https://portal-mf-api-portal.${Environment.baseUrl}/'));

  @override
  Future<Token?> getToken(
      {required String user, required String password}) async {
    try {
      final response = await dio
          .post("portal/sso/token", data: {"user": user, "password": password});
      return ResTokenMapper.portalmfapiToResToken(
          PortalmfApi.fromJson(response.data));
    } on DioException catch (error) {
      error;
      return null;
    }
  }

  @override
  Future<Token?> refreshToken({required String refreshToken}) async {
    try {
      final response = await dio.post("portal/sso/token/refresh",
          data: {"refreshToken": refreshToken});
      return ResTokenMapper.portalmfapiToResToken(
          PortalmfApi.fromJson(response.data));
    } on DioException catch (error) {
      error;
      return null;
    }
  }
}

import 'dart:convert';

PortalmfApi portalmfApiFromJson(String str) =>
    PortalmfApi.fromJson(json.decode(str));

String portalmfApiToJson(PortalmfApi data) => json.encode(data.toJson());

class PortalmfApi {
  final String accessToken;
  final String name;
  final int expiresIn;
  final int refreshExpiresIn;
  final String refreshToken;
  final dynamic lastLoginDate;
  final int daysToChangePassword;
  final bool? showNps;

  PortalmfApi({
    required this.accessToken,
    required this.name,
    required this.expiresIn,
    required this.refreshExpiresIn,
    required this.refreshToken,
    this.lastLoginDate,
    required this.daysToChangePassword,
    this.showNps,
  });

  factory PortalmfApi.fromJson(Map<String, dynamic> json) => PortalmfApi(
        accessToken: json["access_token"],
        name: json["name"],
        expiresIn: json["expires_in"],
        refreshExpiresIn: json["refresh_expires_in"],
        refreshToken: json["refresh_token"],
        lastLoginDate: json["last_login_date"],
        daysToChangePassword: json["days_to_change_password"],
        showNps: json["showNps"],
      );

  Map<String, dynamic> toJson() => {
        "access_token": accessToken,
        "name": name,
        "expires_in": expiresIn,
        "refresh_expires_in": refreshExpiresIn,
        "refresh_token": refreshToken,
        "last_login_date": lastLoginDate,
        "days_to_change_password": daysToChangePassword,
        "showNps": showNps,
      };
}

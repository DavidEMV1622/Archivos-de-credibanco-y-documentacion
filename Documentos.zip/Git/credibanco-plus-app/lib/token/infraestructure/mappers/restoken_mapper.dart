import 'package:credibanco_plus_app/token/infraestructure/models/portalmf_api.dart';

import '../../domain/entities/token.dart';

class ResTokenMapper {
  static Token portalmfapiToResToken(PortalmfApi token) => Token(
      accessToken: token.accessToken,
      refreshToken: token.refreshToken,
      lastLoginDate: token.lastLoginDate);
}

import '../../domain/datasources/token_data_source.dart';
import '../../domain/entities/token.dart';

import '../../domain/repositories/token_repository.dart';

class TokenRepositoryImpl extends TokenRepository {
  final TokenDataSource dataSource;

  TokenRepositoryImpl(this.dataSource);

  @override
  Future<Token?> getToken({required String user, required String password}) {
    return dataSource.getToken(user: user, password: password);
  }

  @override
  Future<Token?> refreshToken({required String refreshToken}) {
    return dataSource.refreshToken(refreshToken: refreshToken);
  }
}

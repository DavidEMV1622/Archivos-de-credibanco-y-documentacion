package com.b2b.canalapp.canalapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:credibanco_plus_app/presentation/screens/home_publico/controllers/calc_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:get/get.dart';

void main() {
  final calcController = Get.put(CalcController());
  WidgetsFlutterBinding.ensureInitialized();

  group('Calculator', () {
    test('initial state caclc', () {
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 0");
    });

    test('add Number', () {
      calcController.addNumber("8");
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 8");
    });
    test('Format number for Thounsand', () {
      calcController.addNumber("8");
      calcController.addNumber("8");
      calcController.addNumber("8");
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 8.888");
    });

    test('del number', () {
      calcController.funDel();
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 888");
    });

    test('Func AC', () {
      calcController.funAc();
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 0");
    });

    test('Func AC', () {
      calcController.addNumber("8");
      calcController.addNumber("8");
      calcController.addNumber("8");
      calcController.addNumber("8");
      calcController.addNumber("8");
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "\$ 88.888");
    });

    test("add sum", () {
      calcController.addSum();
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, " 88.888+");
    });

    test("add sum when the last character is a sum", () {
      calcController.addSum();
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, " 88.888+");
    });

    test("add number for sum", () {
      calcController.addNumber("5");
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "88.888+5");
    });

    test("add number for sum", () {
      calcController.addNumber("0");
      final controller = calcController.inputValorCtrl.value!;
      expect(calcController.totalSum.value, "88938");
      expect(controller.text, "88.888+50");
    });

    test("add number for sum", () {
      calcController.funDel();
      final controller = calcController.inputValorCtrl.value!;
      expect(controller.text, "88.888+5");
      expect(calcController.totalSum.value, "88893");
      calcController.funDel();
      calcController.funDel();
      expect(controller.text, "\$ 88.888");
      calcController.funDel();
      calcController.funDel();
      expect(controller.text, "\$ 888");
    });
  });
}
